"use client"

import * as React from "react"

/**
 * JARVIS NEURAL TELEMETRY v20.0
 * High-fidelity hardware monitoring via W3C Device APIs.
 */
export function useDeviceMetrics() {
  const [metrics, setMetrics] = React.useState({
    ram: 0,
    storage: 0,
    battery: 0,
    isCharging: false,
    temp: "Stable" as "Stable" | "Elevated" | "Critical"
  })
  
  const [network, setNetwork] = React.useState({ ping: 0, downlink: 0 })
  const [deviceInfo, setDeviceInfo] = React.useState({ name: "Handset", os: "Neural OS" })
  const [isLoaded, setIsLoaded] = React.useState(false)

  const fetchAll = React.useCallback(async () => {
    // RAM Allocation
    const ram = (navigator as any).deviceMemory || 4
    
    // Storage Quota
    let storage = 0
    if (navigator.storage && navigator.storage.estimate) {
      try {
        const est = await navigator.storage.estimate()
        if (est.usage !== undefined && est.quota !== undefined) {
          storage = Math.round((est.usage / est.quota) * 100)
        }
      } catch (e) {}
    }

    // Power Supply
    let battery = 100
    let isCharging = false
    if ('getBattery' in navigator) {
      try {
        const bat: any = await (navigator as any).getBattery()
        battery = Math.round(bat.level * 100)
        isCharging = bat.charging
      } catch (e) {}
    }

    // Signal Latency
    const start = performance.now()
    let downlink = 0
    let ping = 0
    try {
      await fetch('https://picsum.photos/seed/ping/1/1', { mode: 'no-cors', cache: 'no-cache' })
      const end = performance.now()
      ping = Math.round(end - start)
      const conn = (navigator as any).connection
      downlink = conn ? conn.downlink : 0
    } catch (e) {}

    // Identity
    const ua = navigator.userAgent;
    const os = ua.includes("Android") ? "Android Core" : "System Core";
    
    setNetwork({ ping, downlink });
    setMetrics({ 
      ram, 
      storage, 
      battery, 
      isCharging,
      temp: battery < 20 && isCharging ? "Elevated" : "Stable"
    });
    setDeviceInfo(prev => ({ ...prev, os }));
    setIsLoaded(true)
  }, [])

  React.useEffect(() => {
    fetchAll()
    const interval = setInterval(fetchAll, 30000) 
    return () => clearInterval(interval)
  }, [fetchAll])

  const score = React.useMemo(() => {
    if (!isLoaded) return 0
    let s = 100
    
    // Battery Penalty
    if (metrics.battery < 20 && !metrics.isCharging) s -= 20
    
    // Latency Penalty
    if (network.ping > 500) s -= 15
    else if (network.ping > 200) s -= 5
    
    // Storage Penalty
    if (metrics.storage > 90) s -= 25
    else if (metrics.storage > 75) s -= 10
    
    // Temp Penalty
    if (metrics.temp !== "Stable") s -= 10
    
    return Math.max(0, s)
  }, [metrics, network.ping, isLoaded])

  return { metrics, network, deviceInfo, score, isLoaded, refresh: fetchAll }
}