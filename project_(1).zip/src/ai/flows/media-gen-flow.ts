'use server';
/**
 * JARVIS MEDIA STUDIO - NEURAL CORE
 * Handles high-fidelity image and video synthesis using Genkit.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';
import { googleAI } from '@genkit-ai/google-genai';

/**
 * Generates an image based on user prompt.
 */
export async function generateImageAction(prompt: string): Promise<string> {
  try {
    const { media } = await ai.generate({
      model: 'googleai/imagen-4.0-fast-generate-001',
      prompt: prompt,
    });
    if (!media || !media.url) {
      throw new Error('NEURAL_IMAGE_EMPTY_RESULT');
    }
    return media.url;
  } catch (error: any) {
    console.error('IMAGE_GEN_FAILURE:', error.message);
    throw new Error('MEDIA_ENGINE_CAPACITY_REACHED');
  }
}

/**
 * Generates a video based on user prompt.
 */
export async function generateVideoAction(prompt: string): Promise<string> {
  try {
    let { operation } = await ai.generate({
      model: googleAI.model('veo-3.0-generate-preview'),
      prompt: prompt,
    });

    if (!operation) {
      throw new Error('NEURAL_VIDEO_OP_FAILURE');
    }

    // Long-polling for video generation
    while (!operation.done) {
      operation = await ai.checkOperation(operation);
      if (operation.done) break;
      await new Promise((resolve) => setTimeout(resolve, 5000));
    }

    if (operation.error) {
      throw new Error(operation.error.message);
    }

    const videoPart = operation.output?.message?.content.find((p) => !!p.media);
    if (!videoPart || !videoPart.media) {
      throw new Error('NEURAL_VIDEO_PART_NOT_FOUND');
    }

    const apiKey = process.env.GOOGLE_API_KEY || process.env.GEMINI_API_KEY || "AQ.Ab8RN6KKBgQeEK4u1jEyM-Mfjw_hx6Hb2xnJUo-HTOqjckrGOw";
    return `${videoPart.media.url}&key=${apiKey}`;
  } catch (error: any) {
    console.error('VIDEO_GEN_FAILURE:', error.message);
    throw new Error('MEDIA_ENGINE_CAPACITY_REACHED');
  }
}
