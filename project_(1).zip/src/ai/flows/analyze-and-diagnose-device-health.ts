'use server';
/**
 * JARVIS NEURAL CORE - SERVER BRIDGE
 * Simplified server action for background AI tasks using Groq SDK.
 */

import Groq from 'groq-sdk';

const API_KEY = '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';
const groq = new Groq({ apiKey: API_KEY });

export async function sendMessageToJarvis(userInput: string): Promise<string> {
  try {
    const chat = await groq.chat.completions.create({
      messages: [{ role: 'user', content: userInput }],
      model: 'llama3-70b-8192',
    });

    return chat.choices[0]?.message?.content || '[SYSTEM]: Null response.';
  } catch (error: any) {
    console.error('NEURAL_HANDSHAKE_FAILURE:', error.message);
    return 'Error: Connection failed.';
  }
}
