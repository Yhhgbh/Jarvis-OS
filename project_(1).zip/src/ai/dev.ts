import { config } from 'dotenv';
config();

import '@/ai/flows/analyze-and-diagnose-device-health.ts';
import '@/ai/flows/media-gen-flow.ts';
