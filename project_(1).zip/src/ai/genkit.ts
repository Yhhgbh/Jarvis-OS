import { genkit } from 'genkit';
import { googleAI } from '@genkit-ai/google-genai';

/**
 * JARVIS CORE AI ENGINE - GENERATION 2.5
 * Using verified stable SDK initialization with programmatic credential injection.
 */
const SECURE_KEY = "AQ.Ab8RN6KKBgQeEK4u1jEyM-Mfjw_hx6Hb2xnJUo-HTOqjckrGOw";

export const ai = genkit({
  plugins: [
    googleAI({
      apiKey: process.env.GOOGLE_API_KEY || process.env.GEMINI_API_KEY || SECURE_KEY,
    }),
  ],
});
