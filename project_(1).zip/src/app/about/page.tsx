"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Sparkles, Heart, Activity, Award, ShieldCheck, Cpu } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="flex flex-col min-h-screen bg-black text-[#00f2ff]">
      <div className="container max-w-md mx-auto p-6 pt-24 space-y-8 pb-32">
        <div className="text-center space-y-4">
          <div className="inline-block p-6 rounded-3xl bg-primary/10 text-primary shadow-2xl neon-glow">
            <Activity className="h-12 w-12" />
          </div>
          <div className="space-y-2">
            <h1 className="text-4xl font-black tracking-tighter uppercase">JARVIS OS</h1>
            <p className="text-[10px] font-black uppercase tracking-[0.5em] text-primary">Identity Protocol v19.0</p>
          </div>
        </div>

        <Card className="glass-card border-none neon-glow">
          <CardContent className="p-8 space-y-8">
            <div className="flex items-center gap-6">
              <div className="h-16 w-16 rounded-3xl bg-primary flex items-center justify-center font-black text-2xl text-primary-foreground shadow-lg">TJ</div>
              <div>
                <p className="text-xl font-black tracking-tighter uppercase leading-none">Tarun Joshi</p>
                <p className="text-[10px] font-bold text-primary uppercase tracking-widest mt-2">Lead Architect & Developer</p>
              </div>
            </div>

            <div className="space-y-6 pt-6 border-t border-white/5">
              <p className="text-[12px] font-bold leading-relaxed opacity-70 uppercase text-center">
                JARVIS is a hardware-integrated Neural Ecosystem engineered for elite device performance and multi-modal AI studio capabilities. 
                Designed and developed exclusively by Tarun Joshi.
              </p>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 rounded-3xl bg-black/40 border border-white/5 text-center">
                  <p className="text-[9px] font-black uppercase opacity-40 mb-2">Architecture</p>
                  <p className="text-[11px] font-black text-primary uppercase">Stark Core v19</p>
                </div>
                <div className="p-4 rounded-3xl bg-black/40 border border-white/5 text-center">
                  <p className="text-[9px] font-black uppercase opacity-40 mb-2">Status</p>
                  <p className="text-[11px] font-black text-green-500 uppercase">Operational</p>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center gap-4 p-4 rounded-2xl bg-white/[0.02] border border-white/5">
                  <ShieldCheck className="w-5 h-5 text-primary" />
                  <span className="text-[10px] font-black uppercase">Identity Lock Verified</span>
                </div>
                <div className="flex items-center gap-4 p-4 rounded-2xl bg-white/[0.02] border border-white/5">
                  <Cpu className="w-5 h-5 text-primary" />
                  <span className="text-[10px] font-black uppercase">Hardware-Sync Ready</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="flex flex-col items-center gap-6 py-10">
          <div className="flex items-center gap-2 text-[11px] font-black uppercase tracking-[0.4em] text-primary">
            <Award className="w-4 h-4" /> Created by Tarun Joshi
          </div>
          <div className="flex items-center gap-2 opacity-20 text-[9px] font-black uppercase tracking-[0.4em]">
            Precision Engineering <Heart className="h-3 w-3 text-primary fill-current" /> India
          </div>
        </div>
      </div>
    </div>
  )
}
