import { redirect } from 'next/navigation';

/**
 * Wallpaper system decommissioned.
 * Redirecting to core utility dashboard.
 */
export default function WallpapersPage() {
  redirect('/dashboard');
}
