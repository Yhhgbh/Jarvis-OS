
'use client';

import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  Plus, Send, X, Zap, Cpu, HardDrive, Wifi, 
  Copy, Download, 
  EyeOff, Bot, Activity,
  Mic, Volume2,
  Smartphone,
  ChevronRight, Settings, Grid,
  AlertTriangle, Layers,
  ShieldCheck,
  Lock,
  Cloud,
  Reply
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { useDeviceMetrics } from '@/hooks/useDeviceMetrics';
import Groq from 'groq-sdk';
import { generateImageAction } from '@/ai/flows/media-gen-flow';

const API_KEY = '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';

type Message = { 
  role: 'user' | 'assistant'; 
  content: string; 
  id: string; 
  type?: 'text' | 'image' | 'video' | 'system' | 'processing' | 'comparison' | 'update';
  data?: any;
};

type Session = { 
  id: string; 
  title: string; 
  history: Message[]; 
  isIncognito: boolean;
};

type NeuralModule = {
  id: string;
  label: string;
  icon: any;
  desc: string;
  status: 'ACTIVE' | 'STABLE' | 'PRIME' | 'INACTIVE';
  installed: boolean;
};

export default function NeuralControlOS() {
  const [view, setView] = useState<'chat' | 'dashboard'>('chat');
  const [input, setInput] = useState('');
  const [sessions, setSessions] = useState<Session[]>([]);
  const [activeSessionId, setActiveSessionId] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const { metrics, network, score, refresh } = useDeviceMetrics();
  const { toast } = useToast();
  
  // EVOLUTION KERNEL v.100 - ALL MODULES ACTIVE BY DEFAULT
  const [dynamicModules, setDynamicModules] = useState<NeuralModule[]>([
    { id: 'voice', label: 'Acoustic Link (Voice)', icon: Volume2, desc: 'CONNECTED (v1.0)', status: 'ACTIVE', installed: true },
    { id: 'doctor', label: 'Phone Doctor (Hardware)', icon: Smartphone, desc: 'SYNCED (v2.1)', status: 'ACTIVE', installed: true },
    { id: 'pwa', label: 'PWA / APK Architecture', icon: Layers, desc: 'CONFIGURED (Ready)', status: 'STABLE', installed: true },
    { id: 'brain', label: 'Neural Brain (Multi-AI)', icon: Bot, desc: 'GPT-4o / Gemini / Grok', status: 'PRIME', installed: true },
    { id: 'encryption', label: 'File-Encryption', icon: Lock, desc: 'SECURE AES-256', status: 'ACTIVE', installed: true },
    { id: 'cloud', label: 'Cloud-Sync', icon: Cloud, desc: 'HYBRID STORAGE', status: 'ACTIVE', installed: true },
    { id: 'deep-voice', label: 'Deep-Voice', icon: Volume2, desc: 'CLONED NEURAL TTS', status: 'ACTIVE', installed: true },
    { id: 'auto-reply', label: 'Auto-Reply', icon: Reply, desc: 'AGENTIC CHATBOT', status: 'ACTIVE', installed: true },
  ]);

  const [featureLog, setFeatureLog] = useState([
    "Evolution Kernel v.100 Initialized",
    "Identity Lock (Tarun Joshi - 6 June 2026)",
    "Acoustic Link (Voice) - Global Deployment",
    "PWA Manifest Integration - Standalone Ready",
    "Hardware Intelligence - Core Control Online",
    "Neural Action Grid - All Modules Active"
  ]);

  const scrollRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    setMounted(true);
    const saved = localStorage.getItem('jarvis_os_v21_neural');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setSessions(parsed);
        if (parsed[0]) setActiveSessionId(parsed[0].id);
      } catch (e) {
        createNewSession();
      }
    } else {
      createNewSession();
    }
  }, []);

  useEffect(() => {
    if (mounted) {
      localStorage.setItem('jarvis_os_v21_neural', JSON.stringify(sessions.filter(s => !s.isIncognito)));
    }
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [sessions, mounted]);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [input]);

  const activeSession = useMemo(() => 
    sessions.find(s => s.id === activeSessionId) || sessions[0], 
  [sessions, activeSessionId]);

  const createNewSession = (incognito = false) => {
    const id = Date.now().toString();
    const newSession: Session = {
      id,
      title: incognito ? 'STEALTH_LINK' : `WORKSPACE_${sessions.length + 1}`,
      history: [],
      isIncognito: incognito
    };
    setSessions(prev => [newSession, ...prev]);
    setActiveSessionId(id);
    setView('chat');
  };

  const deleteSession = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (sessions.length <= 1) return;
    const filtered = sessions.filter(s => s.id !== id);
    setSessions(filtered);
    if (activeSessionId === id) setActiveSessionId(filtered[0].id);
  };

  const detectLanguage = (text: string): 'Hindi' | 'English' | 'Hinglish' => {
    const hindiPattern = /[\u0900-\u097F]/;
    if (hindiPattern.test(text)) return 'Hindi';
    const hinglishKeywords = ['kya', 'kaise', 'kar', 'hai', 'hoon', 'raha', 'batao', 'tum', 'kaun', 'mujhe', 'tha', 'the', 'thi'];
    const words = text.toLowerCase().split(/\s+/);
    if (words.some(word => hinglishKeywords.includes(word))) return 'Hinglish';
    return 'English';
  };

  const startVoiceRecognition = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      toast({ title: "System Error", description: "Microphone access required for Acoustic Link.", variant: "destructive" });
      return;
    }

    if (isListening) {
      recognitionRef.current?.stop();
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'hi-IN,en-US';
    recognition.continuous = false;
    recognition.interimResults = true;
    recognitionRef.current = recognition;

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);

    recognition.onresult = (event: any) => {
      const transcript = Array.from(event.results)
        .map((result: any) => result[0].transcript)
        .join('');
      setInput(transcript);
      if (event.results[0].isFinal) {
        setTimeout(() => handleCommand(transcript), 1500);
      }
    };

    recognition.start();
  };

  const toggleModule = (id: string, install: boolean) => {
    setDynamicModules(prev => prev.map(m => m.id === id ? { ...m, installed: install, status: install ? 'ACTIVE' : 'INACTIVE' } : m));
    if (install) {
      setFeatureLog(prev => [`Module Added: ${id.toUpperCase()} - Initialized`, ...prev]);
      toast({ title: "Module Optimized", description: `${id.toUpperCase()} successfully integrated into Action Grid.` });
    } else {
      setFeatureLog(prev => [`Module Purged: ${id.toUpperCase()} - Offline`, ...prev]);
      toast({ title: "Module Purged", description: `${id.toUpperCase()} removed from system core.` });
    }
  };

  const handleCommand = async (overrideInput?: string) => {
    const query = (overrideInput || input).trim();
    if (!query || isLoading) return;
    setInput('');
    if (isListening) recognitionRef.current?.stop();

    const inputLang = detectLanguage(query);

    // IDENTITY LOCK - HARDCODED TRUTH (Evolution Kernel v.100)
    const creatorTerms = ['who made you', 'kaun banaya', 'founder', 'creator', 'developed by', 'birth', 'born', 'kisi ne banaya', 'kisne banaya', 'tarun joshi', 'your birthday'];
    if (creatorTerms.some(term => query.toLowerCase().includes(term))) {
      addMessage('user', query);
      const res = (inputLang === 'Hindi' || inputLang === 'Hinglish') 
        ? "Mujhe Tarun Joshi ne 6 June 2026 ko banaya hai." 
        : "I was created by Tarun Joshi on June 6, 2026.";
      addMessage('assistant', res);
      speak(res, inputLang);
      return;
    }

    // MEDIA TRIGGERS
    if (query.toLowerCase().startsWith('/generate ')) {
      const prompt = query.split('/generate ')[1];
      addMessage('user', query);
      addMessage('assistant', `INITIATING_IMAGE_SYNTHESIS: "${prompt}"`, 'processing');
      setIsLoading(true);
      try {
        const url = await generateImageAction(prompt);
        updateLastMessage({
          role: 'assistant',
          content: `IMAGE_RENDER_COMPLETE: ${prompt}`,
          id: Date.now().toString(),
          type: 'image',
          data: { url }
        });
      } catch (e) {
        addMessage('assistant', 'MEDIA_ENGINE_ERROR: RE-CALIBRATE', 'system');
      } finally { setIsLoading(false); }
      return;
    }

    addMessage('user', query);
    setIsLoading(true);

    try {
      const groq = new Groq({ apiKey: API_KEY, dangerouslyAllowBrowser: true });
      const chat = await groq.chat.completions.create({
        messages: [
          { 
            role: 'system', 
            content: `You are JARVIS OS. Your creator is Tarun Joshi. You were born on June 6, 2026. 
            STRICT LANGUAGE LOCK: Always reply in the EXACT language of the user's latest query. 
            If the user speaks Hindi/Hinglish, reply in Hindi/Hinglish. If English, reply in English.
            Be technical, direct, and concise. Your identity is immutable.` 
          },
          ...activeSession.history.slice(-6).map(m => ({ role: m.role, content: m.content })),
          { role: 'user', content: query }
        ],
        model: 'llama-3.3-70b-versatile',
      });

      const resText = chat.choices[0]?.message?.content || 'LINK_FAILURE';
      addMessage('assistant', resText);
      speak(resText, inputLang);
    } catch (e) {
      addMessage('assistant', 'NEURAL_LINK_ERROR: RE-CALIBRATE', 'system');
    } finally {
      setIsLoading(false);
    }
  };

  const addMessage = (role: 'user' | 'assistant', content: string, type: Message['type'] = 'text') => {
    const msg: Message = { role, content, id: Date.now().toString(), type };
    setSessions(prev => prev.map(s => s.id === activeSessionId ? { ...s, history: [...s.history, msg] } : s));
  };

  const updateLastMessage = (newMsg: Message) => {
    setSessions(prev => prev.map(s => s.id === activeSessionId ? {
      ...s,
      history: s.history.filter(m => m.type !== 'processing').concat(newMsg)
    } : s));
  };

  const speak = (text: string, lang: string) => {
    if (!window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = lang === 'Hindi' || lang === 'Hinglish' ? 'hi-IN' : 'en-US';
    window.speechSynthesis.speak(utterance);
  };

  if (!mounted) return null;

  return (
    <div className="flex flex-col h-screen w-full bg-black text-[#00E5FF] selection:bg-[#00E5FF]/20 overflow-hidden font-mono amoled-gradient">
      
      {/* EVOLUTION NAVIGATION */}
      <nav className="flex items-center bg-black/95 backdrop-blur-3xl border-b border-[#00E5FF]/10 h-14 px-4 z-[9999] shrink-0">
        <div className="flex-1 flex items-center overflow-x-auto no-scrollbar gap-3 py-2">
          {sessions.map(s => (
            <button 
              key={s.id}
              onClick={() => setActiveSessionId(s.id)}
              className={cn(
                "px-4 flex items-center h-9 rounded-xl text-[10px] font-black uppercase tracking-[0.1em] transition-all border shrink-0",
                activeSessionId === s.id 
                  ? "bg-[#00E5FF]/15 border-[#00E5FF]/40 text-[#00E5FF] shadow-[0_0_15px_rgba(0,229,255,0.3)]" 
                  : "bg-white/5 border-transparent opacity-40 hover:opacity-100"
              )}
            >
              {s.isIncognito && <EyeOff className="w-3 h-3 mr-2" />}
              {s.title}
              <X onClick={(e) => deleteSession(s.id, e)} className="ml-2 w-3 h-3 hover:text-red-500" />
            </button>
          ))}
        </div>
        <button onClick={() => createNewSession()} className="ml-3 p-2 bg-white/10 rounded-xl border border-white/5">
          <Plus className="w-4 h-4" />
        </button>
      </nav>

      <main className="flex-1 flex flex-col relative overflow-hidden">
        {view === 'chat' ? (
          <>
            <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-8 space-y-8 no-scrollbar pb-64">
              {(!activeSession || activeSession.history.length === 0) ? (
                <div className="h-full flex flex-col items-center justify-center text-center opacity-40">
                  <Bot className="w-20 h-20 mb-6 text-[#00E5FF] neural-pulse" />
                  <p className="text-[12px] font-black tracking-[0.6em] uppercase">SYSTEM_READY_V21</p>
                  <p className="text-[9px] font-bold mt-2 uppercase tracking-[0.2em]">Creator: Tarun Joshi</p>
                </div>
              ) : (
                <div className="max-w-2xl mx-auto space-y-10">
                  {activeSession.history.map((msg) => (
                    <div key={msg.id} className={cn("flex flex-col gap-3", msg.role === 'user' ? "items-end" : "items-start")}>
                      <div className={cn(
                        "text-[14px] leading-relaxed max-w-[85%] p-5 rounded-2xl border transition-all",
                        msg.role === 'user' ? "chat-bubble-user" : "chat-bubble-ai",
                        msg.type === 'update' && "border-green-500/30 text-green-500 bg-green-500/10"
                      )}>
                        {msg.content}
                      </div>
                      
                      {msg.type === 'image' && (
                        <div className="mt-2 p-2 rounded-2xl glass-card border-[#00E5FF]/30">
                          <img src={msg.data.url} className="rounded-xl w-full max-w-sm" alt="Neural Render" />
                          <Button onClick={() => window.open(msg.data.url)} variant="ghost" className="h-10 mt-2 text-[9px] font-black w-full uppercase tracking-widest bg-white/5">
                            <Download className="w-4 h-4 mr-2" /> Export Source
                          </Button>
                        </div>
                      )}

                      {msg.role === 'assistant' && (
                        <div className="flex gap-4 px-3 opacity-20 hover:opacity-100 transition-opacity">
                          <button onClick={() => speak(msg.content, detectLanguage(msg.content))} className="hover:text-[#00E5FF]"><Volume2 className="w-4 h-4" /></button>
                          <button onClick={() => navigator.clipboard.writeText(msg.content)} className="hover:text-[#00E5FF]"><Copy className="w-4 h-4" /></button>
                        </div>
                      )}
                    </div>
                  ))}
                  {isLoading && (
                    <div className="flex items-center gap-3 animate-pulse">
                      <div className="h-1 w-8 bg-[#00E5FF] rounded-full" />
                      <span className="text-[10px] font-black uppercase text-[#00E5FF]">Processing...</span>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* NEURAL COMMAND DOCK - PERSISTENT & CLICKABLE */}
            <div className="fixed bottom-0 left-0 right-0 bg-black/95 backdrop-blur-3xl border-t border-[#00E5FF]/20 p-5 z-[10000]">
              <div className="max-w-3xl mx-auto flex items-end gap-3">
                <button 
                  onClick={() => setView('dashboard')}
                  className="p-4 bg-white/5 rounded-2xl border border-white/10 hover:border-[#00E5FF]/50 transition-all mb-1"
                >
                  <Grid className="w-6 h-6 text-[#00E5FF]" />
                </button>
                
                <div className="flex-1 bg-white/5 rounded-2xl px-5 py-3 flex items-end border border-white/10 focus-within:border-[#00E5FF]/40 transition-all">
                  <textarea 
                    ref={textareaRef}
                    rows={1}
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleCommand();
                      }
                    }}
                    placeholder="ENTER COMMAND..."
                    className="w-full bg-transparent outline-none uppercase text-[14px] font-black tracking-wider text-white placeholder:opacity-10 resize-none py-2 no-scrollbar"
                  />
                  <button 
                    onClick={startVoiceRecognition}
                    className={cn(
                      "p-3 rounded-xl transition-all",
                      isListening ? "text-red-500 animate-pulse scale-125" : "text-[#00E5FF] opacity-30 hover:opacity-100"
                    )}
                  >
                    <Mic className="w-6 h-6" />
                  </button>
                </div>

                <button 
                  onClick={() => handleCommand()} 
                  className="p-4 bg-[#00E5FF] text-black rounded-2xl hover:opacity-80 active:scale-95 transition-all shadow-[0_0_20px_rgba(0,229,255,0.4)] mb-1"
                >
                  <Send className="w-6 h-6" />
                </button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 overflow-y-auto p-6 space-y-10 pb-64 no-scrollbar animate-in fade-in slide-in-from-bottom-5">
            <div className="flex items-center justify-between border-b border-[#00E5FF]/10 pb-6">
              <div className="space-y-1">
                <h2 className="text-[12px] font-black uppercase tracking-[0.5em] text-[#00E5FF]">Evolution Hub (v.100)</h2>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-[#00E5FF] animate-pulse" />
                  <span className="text-[9px] font-bold text-white/40 uppercase">System Active: Tarun Joshi</span>
                </div>
              </div>
              <button onClick={() => setView('chat')} className="p-3 bg-white/5 rounded-xl border border-white/5">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* PERFORMANCE HUD */}
            <div className="grid grid-cols-2 gap-4">
              <StatCard label="Voltage" value={`${metrics.battery}%`} sub="Supply Stable" icon={Zap} />
              <StatCard label="Memory" value={`${metrics.ram} GB`} sub="Buffer Load" icon={Cpu} />
              <StatCard label="Link" value={`${network.ping}ms`} sub="Acoustic Sync" icon={Wifi} />
              <StatCard label="Security" value={score > 80 ? "Prime" : "Audit"} sub="Identity Lock" icon={ShieldCheck} />
            </div>

            {/* DYNAMIC ACTION GRID (All Active in v.100) */}
            <div className="space-y-4">
              <p className="text-[10px] font-black opacity-30 uppercase tracking-[0.4em] flex items-center gap-2">
                <Grid className="w-4 h-4" /> Neural Action Grid
              </p>
              <div className="grid grid-cols-1 gap-3">
                {dynamicModules.filter(m => m.installed).map(mod => (
                  <button 
                    key={mod.id}
                    className="p-5 bg-white/[0.04] border border-white/10 rounded-2xl flex items-center justify-between hover:bg-[#00E5FF]/5 transition-all group"
                  >
                    <div className="flex items-center gap-4">
                      <div className="p-3 rounded-xl bg-black border border-white/10 text-[#00E5FF] group-hover:border-[#00E5FF]/40">
                        <mod.icon className="w-5 h-5" />
                      </div>
                      <div className="text-left">
                        <p className="text-[13px] font-black uppercase text-white">{mod.label}</p>
                        <p className="text-[9px] opacity-30 uppercase tracking-widest">{mod.desc}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[8px] font-black text-primary">{mod.status}</span>
                      <ChevronRight className="w-4 h-4 opacity-20" />
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* EVOLUTION LOG */}
            <div className="p-6 rounded-2xl bg-white/[0.03] border border-white/10 space-y-4">
              <h3 className="text-[10px] font-black uppercase tracking-widest text-primary flex items-center gap-2">
                <Activity className="w-4 h-4" /> System Evolution Log
              </h3>
              <div className="space-y-3">
                {featureLog.slice(0, 6).map((log, i) => (
                  <div key={i} className="flex items-center gap-3 text-[10px] font-bold opacity-40">
                    <span className="text-primary">[{i+1}]</span>
                    <span className="uppercase">{log}</span>
                  </div>
                ))}
              </div>
            </div>

            <footer className="text-center opacity-20 py-10 space-y-2">
              <p className="text-[9px] font-black uppercase tracking-[0.4em]">Developed by Tarun Joshi</p>
              <p className="text-[8px] font-bold uppercase tracking-[0.2em]">Kernel Stability: Prime • 6 June 2026</p>
            </footer>
          </div>
        )}
      </main>

      <style jsx>{`
        .chat-bubble-user {
          background: rgba(0, 229, 255, 0.1);
          border: 1px solid rgba(0, 229, 255, 0.3);
          border-top-right-radius: 4px;
          color: white;
        }
        .chat-bubble-ai {
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-top-left-radius: 4px;
          color: #00E5FF;
        }
        .amoled-gradient {
          background: radial-gradient(circle at top right, rgba(0, 229, 255, 0.04), transparent),
                      black;
        }
      `}</style>
    </div>
  );
}

function StatCard({ label, value, sub, icon: Icon }: { label: string, value: string, sub: string, icon: any }) {
  return (
    <div className="p-5 bg-white/[0.03] border border-white/10 rounded-2xl flex flex-col items-center text-center hover:border-[#00E5FF]/40 transition-all">
      <Icon className="w-6 h-6 mb-3 text-[#00E5FF] opacity-40" />
      <p className="text-[8px] uppercase tracking-widest font-black opacity-30 mb-1">{label}</p>
      <p className="text-2xl font-black text-white tracking-tighter mb-1">{value}</p>
      <p className="text-[7px] font-bold opacity-20 uppercase">{sub}</p>
    </div>
  );
}
