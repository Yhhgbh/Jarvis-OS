"use client"

import * as React from "react"
import { Quote, Sparkles, CalendarDays, Heart, BellRing, Navigation as NavIcon } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const DEVOTIONAL_DATA = {
  quote: {
    text: "Set your heart on doing good. Do it over and over again and you will be filled with joy.",
    source: "Divine Wisdom"
  },
  shlok: {
    sanskrit: "karmanye vadhikaraste ma phaleshu kadachana | ma karmaphalaheturbhurma te sangostvakarmani ||",
    meaning: "You have a right to perform your prescribed duties, but you are not entitled to the fruits of your actions."
  },
  mantra: [
    { name: "Om Namah Shivaya", benefit: "Inner Peace & Clarity" },
    { name: "Hare Krishna Maha Mantra", benefit: "Spiritual Elevation" },
    { name: "Gayatri Mantra", benefit: "Intellect & Enlightenment" }
  ],
  festivals: [
    { name: "Maha Shivaratri", date: "Upcoming", status: "Preparation" },
    { name: "Holi", date: "March 2024", status: "Festival of Colors" }
  ]
}

export default function DevotionalHubPage() {
  return (
    <div className="flex flex-col min-h-screen amoled-gradient px-6 pt-24 space-y-6 pb-32">
      <div className="space-y-1">
        <h1 className="text-3xl font-black tracking-tighter uppercase text-white leading-none">Devotional Hub</h1>
        <p className="text-[10px] font-bold text-primary uppercase tracking-[0.4em] mt-1">Daily Spiritual Nourishment</p>
      </div>

      {/* Daily Shlok Card */}
      <Card className="glass-card border-none bg-primary/5 relative overflow-hidden">
        <div className="absolute -top-4 -right-4 h-24 w-24 bg-primary/10 rounded-full blur-2xl" />
        <CardContent className="p-6 space-y-4">
          <div className="flex items-center gap-2 text-primary">
            <Quote className="h-5 w-5" />
            <span className="text-[10px] font-black uppercase tracking-widest">Shlok of the Day</span>
          </div>
          <div className="space-y-4">
            <p className="text-sm font-bold text-white italic leading-relaxed text-center">
              "{DEVOTIONAL_DATA.shlok.sanskrit}"
            </p>
            <div className="p-3 rounded-xl bg-black/40 border border-white/5">
              <p className="text-[10px] font-bold text-muted-foreground leading-relaxed uppercase">
                {DEVOTIONAL_DATA.shlok.meaning}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Mantras Section */}
      <section className="space-y-4">
        <h3 className="text-[11px] font-black uppercase tracking-widest text-muted-foreground flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-yellow-500" /> Sacred Mantras
        </h3>
        <div className="grid grid-cols-1 gap-3">
          {DEVOTIONAL_DATA.mantra.map((m, i) => (
            <Card key={i} className="glass-card border-none">
              <CardContent className="p-4 flex items-center justify-between">
                <div className="space-y-0.5">
                  <p className="text-sm font-black text-white uppercase">{m.name}</p>
                  <p className="text-[9px] font-bold text-primary uppercase">{m.benefit}</p>
                </div>
                <Badge className="bg-primary/10 text-primary border-primary/20">Active</Badge>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Festivals Section */}
      <section className="space-y-4">
        <h3 className="text-[11px] font-black uppercase tracking-widest text-muted-foreground flex items-center gap-2">
          <CalendarDays className="h-4 w-4" /> Upcoming Festivals
        </h3>
        <div className="grid grid-cols-2 gap-3">
          {DEVOTIONAL_DATA.festivals.map((f, i) => (
            <Card key={i} className="glass-card border-none">
              <CardContent className="p-4 space-y-2">
                <p className="text-[10px] font-black text-white uppercase">{f.name}</p>
                <div className="flex flex-col gap-1">
                  <p className="text-[8px] font-bold text-primary uppercase">{f.date}</p>
                  <p className="text-[7px] font-bold text-muted-foreground uppercase">{f.status}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <footer className="text-center pt-8">
        <p className="text-[10px] font-black uppercase tracking-widest text-primary opacity-40">DevAura Spiritual Hub</p>
      </footer>
    </div>
  )
}
