"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Shield, Lock, EyeOff, Activity } from "lucide-react"
import { Navigation } from "@/components/Navigation"

export default function PrivacyPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navigation />
      <div className="container max-w-md mx-auto p-4 pt-20 space-y-6 pb-20">
        <div className="text-center space-y-2">
          <div className="inline-block p-3 rounded-2xl bg-primary/10 text-primary mb-2">
            <Shield className="h-8 w-8" />
          </div>
          <h1 className="text-2xl font-black tracking-tighter uppercase">JARVIS Shield</h1>
          <p className="text-[10px] font-bold uppercase tracking-widest opacity-40">Data Integrity & User Security</p>
        </div>

        <div className="space-y-4">
          <PrivacyCard 
            icon={Lock} 
            title="Sandbox Verification" 
            desc="JARVIS operates within the secure browser sandbox. We only access metrics exposed via official W3C hardware APIs." 
          />
          <PrivacyCard 
            icon={EyeOff} 
            title="Zero Data Tracking" 
            desc="All diagnostic analysis happens on-device. No personal identifiers, geolocation, or history is ever sent to our servers." 
          />
          <PrivacyCard 
            icon={Activity} 
            title="Neural Transparency" 
            desc="We never simulate hardware issues. Every metric shown is a raw value sourced directly from your device sensors." 
          />
        </div>

        <footer className="text-center opacity-20 pt-8">
          <p className="text-[9px] font-black uppercase tracking-[0.4em]">Audit: Jan 2024 • JARVIS Core V2.5</p>
        </footer>
      </div>
    </div>
  )
}

function PrivacyCard({ icon: Icon, title, desc }: any) {
  return (
    <Card className="glass-card border-none">
      <CardContent className="p-6 flex gap-4">
        <div className="shrink-0 h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
          <Icon className="h-5 w-5" />
        </div>
        <div className="space-y-1">
          <h3 className="text-[11px] font-black uppercase tracking-widest">{title}</h3>
          <p className="text-[10px] font-bold opacity-50 leading-relaxed uppercase">{desc}</p>
        </div>
      </CardContent>
    </Card>
  )
}
