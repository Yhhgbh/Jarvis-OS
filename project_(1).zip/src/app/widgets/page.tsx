"use client"

import * as React from "react"
import { Clock, Smartphone, Layers, Plus } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import { useToast } from "@/hooks/use-toast"

const CLOCK_WIDGETS = [
  { id: "mahadev", name: "Mahadev Clock", img: "mahadev-hero" },
  { id: "ram", name: "Shri Ram Clock", img: "ram-hero" },
  { id: "krishna", name: "Krishna Clock", img: "krishna-hero" },
  { id: "om", name: "Vedic Om Clock", img: "ganesh-hero" },
]

export default function WidgetsPage() {
  const { toast } = useToast()
  const [time, setTime] = React.useState(new Date())

  React.useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000)
    return () => clearInterval(timer)
  }, [])

  const handleAddWidget = (name: string) => {
    toast({
      title: "Widget Installed",
      description: `${name} has been added to your device desktop.`,
    })
  }

  const timeString = time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true })

  return (
    <div className="flex flex-col min-h-screen amoled-gradient px-6 pt-24 space-y-6 pb-32">
      <div className="space-y-1">
        <h1 className="text-3xl font-black tracking-tighter uppercase text-white leading-none">Spiritual Widgets</h1>
        <p className="text-[10px] font-bold text-primary uppercase tracking-[0.4em] mt-1">Live Desktop Components</p>
      </div>

      <div className="space-y-4">
        <h3 className="text-[11px] font-black uppercase tracking-widest text-muted-foreground flex items-center gap-2">
          <Layers className="h-4 w-4" /> Live Clock Preview
        </h3>
        
        <Card className="glass-card border-none bg-black overflow-hidden relative aspect-square flex items-center justify-center">
          <div className="absolute inset-0 bg-primary/5" />
          <div className="relative z-10 text-center space-y-4">
            <div className="h-40 w-40 rounded-full border-4 border-primary/20 flex items-center justify-center relative">
              <div className="absolute inset-0 rounded-full border-4 border-primary border-t-transparent animate-spin duration-[10s]" />
              <div className="flex flex-col items-center">
                <span className="text-3xl font-black text-white tracking-tighter">{timeString.split(' ')[0]}</span>
                <span className="text-[10px] font-black text-primary uppercase">{timeString.split(' ')[1]}</span>
              </div>
            </div>
            <p className="text-[10px] font-black text-white uppercase tracking-widest">Active System Time</p>
          </div>
        </Card>
      </div>

      <section className="space-y-4">
        <h3 className="text-[11px] font-black uppercase tracking-widest text-muted-foreground flex items-center gap-2">
          <Smartphone className="h-4 w-4" /> Divine Clock Themes
        </h3>
        <div className="grid grid-cols-1 gap-4">
          {CLOCK_WIDGETS.map((widget) => (
            <Card key={widget.id} className="glass-card border-none overflow-hidden">
              <CardContent className="p-4 flex items-center gap-4">
                <div className="h-20 w-20 relative rounded-2xl overflow-hidden bg-white/5 shrink-0">
                  <Image 
                    src={`https://picsum.photos/seed/${widget.img}/200/200`}
                    alt={widget.name}
                    fill
                    className="object-cover opacity-60"
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Clock className="h-8 w-8 text-white drop-shadow-xl" />
                  </div>
                </div>
                <div className="flex-1 space-y-3">
                  <div>
                    <p className="text-sm font-black text-white uppercase">{widget.name}</p>
                    <p className="text-[9px] font-bold text-muted-foreground uppercase">Interactive Widget</p>
                  </div>
                  <Button 
                    onClick={() => handleAddWidget(widget.name)}
                    className="h-9 w-full rounded-xl bg-primary text-white font-black uppercase text-[9px] tracking-widest gap-2"
                  >
                    <Plus className="h-3 w-3" /> Add to Home
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    </div>
  )
}
