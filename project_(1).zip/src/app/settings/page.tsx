
"use client"

import * as React from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Button } from "@/components/ui/button"
import { Shield, Bell, RefreshCcw, User, Sparkles, Info } from "lucide-react"
import Link from "next/link"

export default function SettingsPage() {
  const [settings, setSettings] = React.useState({
    autoScan: true,
    notifications: true,
    spiritualDaily: true,
  })

  return (
    <div className="flex flex-col min-h-screen amoled-gradient">
      <main className="container max-w-md mx-auto p-6 pt-20 space-y-6 pb-24">
        <div className="space-y-1">
          <h1 className="text-2xl font-black tracking-tighter uppercase text-white leading-none">Settings</h1>
          <p className="text-[10px] font-bold uppercase text-primary tracking-[0.3em] mt-1">DevAura Preferences</p>
        </div>

        <Card className="glass-card border-none">
          <CardHeader>
            <CardTitle className="text-sm font-black uppercase tracking-widest flex items-center gap-2 text-primary">
              <Sparkles className="h-4 w-4" /> Divine Sync
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-xs font-bold uppercase text-white">Daily Devotion</Label>
                <p className="text-[9px] text-muted-foreground uppercase">Spiritual updates & quotes</p>
              </div>
              <Switch 
                checked={settings.spiritualDaily} 
                onCheckedChange={(v) => setSettings(s => ({...s, spiritualDaily: v}))} 
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-xs font-bold uppercase text-white">Push Notifications</Label>
                <p className="text-[9px] text-muted-foreground uppercase">Updates for holy festivals</p>
              </div>
              <Switch 
                checked={settings.notifications} 
                onCheckedChange={(v) => setSettings(s => ({...s, notifications: v}))} 
              />
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-none">
          <CardHeader>
            <CardTitle className="text-sm font-black uppercase tracking-widest flex items-center gap-2 text-primary">
              <Shield className="h-4 w-4" /> System Health
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-xs font-bold uppercase text-white">Startup Scan</Label>
                <p className="text-[9px] text-muted-foreground uppercase">Run health audit on launch</p>
              </div>
              <Switch 
                checked={settings.autoScan} 
                onCheckedChange={(v) => setSettings(s => ({...s, autoScan: v}))} 
              />
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-none">
          <CardHeader>
            <CardTitle className="text-sm font-black uppercase tracking-widest flex items-center gap-2 text-primary">
              <Info className="h-4 w-4" /> Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Link href="/about" className="flex items-center justify-between p-4 rounded-2xl bg-white/[0.02] border border-white/5 active:scale-95 transition-all">
               <div className="flex items-center gap-3">
                  <User className="h-4 w-4 text-muted-foreground" />
                  <span className="text-xs font-black uppercase text-white">About DevAura</span>
               </div>
               <span className="text-[10px] font-bold text-primary uppercase">View</span>
            </Link>
          </CardContent>
        </Card>

        <Button variant="destructive" className="w-full h-14 rounded-2xl font-black uppercase tracking-widest text-xs flex items-center justify-center gap-2 shadow-xl shadow-primary/10 mt-4">
          <RefreshCcw className="h-4 w-4" /> Reset Application
        </Button>

        <footer className="text-center space-y-2 py-8">
          <div className="flex flex-col items-center justify-center gap-1 opacity-60">
            <span className="text-[10px] font-black uppercase tracking-widest text-primary">Created by Tarun Joshi</span>
          </div>
          <p className="text-[8px] font-black uppercase tracking-[0.4em] opacity-10">DevAura V1.1.0 • Stable Build</p>
        </footer>
      </main>
    </div>
  )
}
