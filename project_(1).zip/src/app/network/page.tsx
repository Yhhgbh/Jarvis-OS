"use client"

import * as React from "react"
import { Wifi, Signal, Globe, Server, Activity, RefreshCw } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { cn } from "@/lib/utils"

export default function NetworkDoctorPage() {
  const [testing, setTesting] = React.useState(false)
  const [stats, setStats] = React.useState({ ping: 0, downlink: 0 })
  const [progress, setProgress] = React.useState(0)

  const runTest = async () => {
    setTesting(true)
    setProgress(0)
    
    // Simulate complex neural analysis
    const interval = setInterval(() => {
      setProgress(p => {
        if (p >= 100) {
          clearInterval(interval)
          return 100
        }
        return p + 5
      })
    }, 100)

    const start = performance.now()
    try {
      await fetch('https://picsum.photos/seed/test/1/1', { mode: 'no-cors', cache: 'no-cache' })
      const end = performance.now()
      const ping = Math.round(end - start)
      const conn = (navigator as any).connection
      const downlink = conn ? conn.downlink : 0
      
      setTimeout(() => {
        setStats({ ping, downlink })
        setTesting(false)
      }, 2000)
    } catch (e) {
      setTesting(false)
    }
  }

  return (
    <div className="flex flex-col min-h-screen amoled-gradient px-6 pt-24 space-y-6">
      <div className="space-y-1">
        <h1 className="text-2xl font-black tracking-tighter uppercase text-white">Network Doctor</h1>
        <p className="text-[10px] font-bold text-primary uppercase tracking-[0.3em]">ISP Link Audit</p>
      </div>

      <div className="flex flex-col items-center justify-center py-12 gap-8">
        <div className="relative">
          <div className="absolute inset-0 bg-primary/20 blur-3xl rounded-full" />
          <Wifi className={cn("h-24 w-24 text-primary relative z-10", testing && "animate-pulse")} />
        </div>
        
        {testing ? (
          <div className="w-full space-y-4">
             <div className="flex justify-between text-[10px] font-black uppercase tracking-widest text-muted-foreground">
                <span>Analyzing Neural Link...</span>
                <span className="text-primary">{progress}%</span>
             </div>
             <Progress value={progress} className="h-2 rounded-full" />
          </div>
        ) : (
          <Button onClick={runTest} className="w-64 h-16 rounded-3xl bg-primary text-white font-black uppercase tracking-widest text-xs shadow-xl shadow-primary/20">
            Initialize Link Scan
          </Button>
        )}
      </div>

      <div className="grid grid-cols-2 gap-4">
        <StatCard label="Response Latency" value={stats.ping ? `${stats.ping} ms` : "--"} sub="Verified Ping" />
        <StatCard label="Carrier Throughput" value={stats.downlink ? `${stats.downlink} Mbps` : "--"} sub="Bandwidth" />
      </div>

      {!testing && stats.ping > 0 && (
        <Card className="glass-card border-none animate-in fade-in slide-in-from-bottom-4 duration-500">
          <CardContent className="p-6 space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-green-500/10 text-green-500">
                <Signal className="h-5 w-5" />
              </div>
              <div>
                <p className="text-[10px] font-black uppercase text-white">Stability Report</p>
                <p className="text-[9px] font-bold text-muted-foreground uppercase">{stats.ping < 200 ? "Link verified stable" : "Network congestion detected"}</p>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-3">
               <div className="p-3 rounded-2xl bg-white/[0.02] border border-white/5 text-center">
                  <p className="text-[8px] font-black opacity-40 uppercase">WiFi Protocol</p>
                  <p className="text-[10px] font-bold text-white uppercase">Linked</p>
               </div>
               <div className="p-3 rounded-2xl bg-white/[0.02] border border-white/5 text-center">
                  <p className="text-[8px] font-black opacity-40 uppercase">Radio Signal</p>
                  <p className="text-[10px] font-bold text-white uppercase">Verified</p>
               </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="pb-12" />
    </div>
  )
}

function StatCard({ label, value, sub }: any) {
  return (
    <Card className="glass-card border-none">
      <CardContent className="p-5 space-y-1 text-center">
        <p className="text-[8px] font-black uppercase text-muted-foreground tracking-widest">{label}</p>
        <p className="text-2xl font-black text-white tracking-tighter">{value}</p>
        <p className="text-[7px] font-bold text-primary uppercase">{sub}</p>
      </CardContent>
    </Card>
  )
}
