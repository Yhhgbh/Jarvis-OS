"use client"

import * as React from "react"
import { Battery, Zap, Thermometer, ShieldCheck, Info } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"

export default function BatteryPage() {
  const [battery, setBattery] = React.useState<{
    level: number;
    charging: boolean;
    chargingTime: number;
    dischargingTime: number;
  } | null>(null)

  React.useEffect(() => {
    if ('getBattery' in navigator) {
      (navigator as any).getBattery().then((bat: any) => {
        const update = () => setBattery({
          level: bat.level,
          charging: bat.charging,
          chargingTime: bat.chargingTime,
          dischargingTime: bat.dischargingTime,
        })
        update()
        bat.addEventListener('levelchange', update)
        bat.addEventListener('chargingchange', update)
      })
    }
  }, [])

  if (!battery) return (
    <div className="p-6 text-center pt-24">
      <p className="text-[10px] font-black uppercase opacity-40">Battery Telemetry Restricted</p>
    </div>
  )

  const levelPercent = Math.round(battery.level * 100)

  return (
    <div className="flex flex-col min-h-screen amoled-gradient px-6 pt-24 space-y-6">
      <div className="flex flex-col items-center gap-6 py-8">
        <div className="relative h-48 w-48 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-8 border-white/5" />
          <div 
            className="absolute inset-0 rounded-full border-8 border-primary border-t-transparent animate-spin duration-1000" 
            style={{ animationDuration: battery.charging ? '2s' : '0s', opacity: battery.charging ? 1 : 0 }}
          />
          <div className="text-center space-y-1 z-10">
            <span className="text-6xl font-black tracking-tighter text-white">{levelPercent}%</span>
            <p className="text-[10px] font-black text-primary uppercase tracking-[0.2em]">{battery.charging ? "Resource Linked" : "Supply Status"}</p>
          </div>
        </div>

        <div className="flex gap-4 w-full">
          <Card className="glass-card flex-1 border-none">
            <CardContent className="p-4 flex flex-col items-center gap-2">
              <Thermometer className="h-5 w-5 text-yellow-500" />
              <p className="text-[8px] font-black uppercase text-muted-foreground">Temp</p>
              <p className="text-xs font-bold">Stable</p>
            </CardContent>
          </Card>
          <Card className="glass-card flex-1 border-none">
            <CardContent className="p-4 flex flex-col items-center gap-2">
              <Zap className="h-5 w-5 text-primary" />
              <p className="text-[8px] font-black uppercase text-muted-foreground">Speed</p>
              <p className="text-xs font-bold">{battery.charging ? "Verified" : "Normal"}</p>
            </CardContent>
          </Card>
          <Card className="glass-card flex-1 border-none">
            <CardContent className="p-4 flex flex-col items-center gap-2">
              <ShieldCheck className="h-5 w-5 text-green-500" />
              <p className="text-[8px] font-black uppercase text-muted-foreground">Health</p>
              <p className="text-xs font-bold">Good</p>
            </CardContent>
          </Card>
        </div>
      </div>

      <Card className="glass-card border-none">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-black uppercase tracking-widest text-primary">Efficiency Optimization</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between text-[9px] font-black uppercase tracking-widest opacity-40">
              <span>Energy Quota</span>
              <span>{levelPercent}%</span>
            </div>
            <Progress value={levelPercent} className="h-2 rounded-full" />
          </div>
          
          <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/5 space-y-2">
            <p className="text-[10px] font-bold text-muted-foreground leading-relaxed uppercase">
              Current power consumption is optimized for AMOLED black theme. System verified no background leakage detected.
            </p>
          </div>

          <Button className="w-full h-14 rounded-2xl bg-primary text-white font-black uppercase tracking-widest text-xs shadow-xl shadow-primary/20">
            Apply Power Saver mode
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
