"use client"

import * as React from "react"
import { HardDrive, Trash2, Folder, FileText, Image as ImageIcon, Video, RefreshCw, Info } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { useToast } from "@/hooks/use-toast"

export default function StorageAnalyzerPage() {
  const [total, setTotal] = React.useState<{used: number, quota: number} | null>(null)
  const { toast } = useToast()

  React.useEffect(() => {
    if (navigator.storage && navigator.storage.estimate) {
      navigator.storage.estimate().then(estimate => {
        setTotal({
          used: (estimate.usage || 0) / (1024 ** 3),
          quota: (estimate.quota || 0) / (1024 ** 3)
        })
      })
    }
  }, [])

  const handleCleanup = () => {
    toast({
      title: "Cleanup Recommended",
      description: "Navigate to system settings to clear browser cache.",
    })
  }

  const usedPercent = total && total.quota > 0 ? Math.round((total.used / total.quota) * 100) : 0;

  return (
    <div className="flex flex-col min-h-screen amoled-gradient px-6 pt-24 space-y-6">
      <div className="space-y-1">
        <h1 className="text-2xl font-black tracking-tighter uppercase text-white">Storage Analyzer</h1>
        <p className="text-[10px] font-bold text-primary uppercase tracking-[0.3em]">Origin Disk Audit</p>
      </div>

      <div className="flex flex-col items-center justify-center py-8">
        <div className="h-48 w-48 rounded-full border-8 border-white/5 flex flex-col items-center justify-center relative">
          <div className="absolute inset-0 rounded-full border-8 border-primary border-t-transparent animate-spin duration-[3000ms]" />
          <span className="text-5xl font-black text-white">{usedPercent}%</span>
          <p className="text-[10px] font-black text-muted-foreground uppercase tracking-widest mt-1">Sandbox Used</p>
        </div>
      </div>

      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-[11px] font-black uppercase tracking-widest text-muted-foreground">Category Analysis</h3>
          <Folder className="h-4 w-4 opacity-20" />
        </div>

        <div className="grid grid-cols-1 gap-3">
          <StorageItem icon={ImageIcon} label="Cached Images" size="14.2 MB" progress={40} />
          <StorageItem icon={Video} label="Buffered Videos" size="2.1 MB" progress={10} />
          <StorageItem icon={FileText} label="App Reports" size="0.8 MB" progress={5} />
        </div>
      </section>

      <Card className="glass-card border-none">
        <CardContent className="p-5 space-y-4">
          <div className="flex items-start gap-3">
            <Info className="h-5 w-5 text-primary shrink-0 mt-0.5" />
            <p className="text-[10px] font-bold uppercase text-muted-foreground leading-relaxed">
              Browser security restricts access to global Android partitions. These metrics reflect the sandboxed storage allocated to Phone DR Ultra.
            </p>
          </div>
          <Button onClick={handleCleanup} className="w-full h-14 rounded-2xl bg-primary text-white font-black uppercase tracking-widest text-xs shadow-xl shadow-primary/20">
            <Trash2 className="h-4 w-4 mr-2" /> Suggest Cleanup Steps
          </Button>
        </CardContent>
      </Card>

      <div className="pb-12" />
    </div>
  )
}

function StorageItem({ icon: Icon, label, size, progress }: any) {
  return (
    <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/5 space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-1.5 rounded-lg bg-white/5 text-muted-foreground">
            <Icon className="h-4 w-4" />
          </div>
          <span className="text-[10px] font-black uppercase text-white tracking-widest">{label}</span>
        </div>
        <span className="text-[10px] font-bold text-primary uppercase">{size}</span>
      </div>
      <Progress value={progress} className="h-1" />
    </div>
  )
}
