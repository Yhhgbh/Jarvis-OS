"use client"

import * as React from "react"
import { ShieldCheck, Download, FileText, CheckCircle2, Loader2, Award } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useDeviceMetrics } from "@/hooks/useDeviceMetrics"
import { useToast } from "@/hooks/use-toast"
import jsPDF from "jspdf"
import html2canvas from "html2canvas"

export default function HealthReportPage() {
  const { metrics, network, deviceInfo, score } = useDeviceMetrics()
  const { toast } = useToast()
  const [isGenerating, setIsGenerating] = React.useState(false)
  const reportRef = React.useRef<HTMLDivElement>(null)

  const handleExport = async () => {
    if (!reportRef.current) return
    setIsGenerating(true)
    try {
      const canvas = await html2canvas(reportRef.current, {
        scale: 2,
        backgroundColor: "#000000",
      })
      const imgData = canvas.toDataURL("image/png")
      const pdf = new jsPDF()
      const imgProps = pdf.getImageProperties(imgData)
      const pdfWidth = pdf.internal.pageSize.getWidth()
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width
      pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight)
      pdf.save(`DevAura_Health_Audit_${new Date().toISOString().split('T')[0]}.pdf`)
      toast({ title: "Report Exported", description: "Audit saved to your downloads." })
    } catch (e) {
      toast({ variant: "destructive", title: "Export Failed", description: "Could not generate PDF." })
    } finally {
      setIsGenerating(false)
    }
  }

  return (
    <div className="flex flex-col min-h-screen amoled-gradient px-6 pt-24 space-y-6">
      <div className="space-y-1">
        <h1 className="text-2xl font-black tracking-tighter uppercase text-white">Device Audit</h1>
        <p className="text-[10px] font-bold text-primary uppercase tracking-[0.3em]">Integrity Verification</p>
      </div>

      <div ref={reportRef} className="space-y-4">
        <Card className="glass-card border-none bg-black">
          <CardContent className="p-6 space-y-6">
            <div className="flex items-center justify-between border-b border-white/5 pb-4">
              <div className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-primary" />
                <span className="text-[10px] font-black uppercase tracking-widest text-white">System Summary</span>
              </div>
              <span className="text-[9px] font-bold uppercase opacity-40">{new Date().toLocaleDateString()}</span>
            </div>

            <div className="space-y-4">
              <ReportRow label="Hardware Score" value={`${score}/100`} />
              <ReportRow label="Battery Integrity" value={metrics.battery ? `${metrics.battery}%` : "Verified"} />
              <ReportRow label="Network Latency" value={`${network.ping}ms`} />
              <ReportRow label="System Model" value={deviceInfo.name} />
              <ReportRow label="RAM Capacity" value={metrics.ram ? `${metrics.ram} GB` : "Factual"} />
            </div>

            <div className="p-4 rounded-2xl bg-primary/5 border border-primary/10 flex items-start gap-3">
              <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p className="text-[10px] font-bold uppercase leading-relaxed text-primary opacity-80">
                  This report is verified via browser-level hardware interfaces. Secure Build V1.
                </p>
                <div className="flex items-center gap-1.5 pt-2 border-t border-primary/10">
                   <Award className="h-3 w-3 text-primary" />
                   <p className="text-[8px] font-black uppercase tracking-widest text-primary">Created by Tarun Joshi</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Button 
        onClick={handleExport}
        disabled={isGenerating}
        className="w-full h-16 rounded-3xl bg-primary text-white font-black uppercase tracking-widest text-xs shadow-xl shadow-primary/20"
      >
        {isGenerating ? <Loader2 className="h-5 w-5 animate-spin mr-2" /> : <Download className="h-5 w-5 mr-2" />}
        Export Audit PDF
      </Button>

      <section className="space-y-4 pb-12">
        <h3 className="text-[11px] font-black uppercase tracking-widest text-muted-foreground">Scoring Protocol</h3>
        <div className="grid grid-cols-1 gap-2">
          <ScoreInfo label="Battery < 20%" impact="-15 PTS" />
          <ScoreInfo label="Latency > 800ms" impact="-25 PTS" />
          <ScoreInfo label="Storage > 90%" impact="-20 PTS" />
        </div>
      </section>
    </div>
  )
}

function ReportRow({ label, value }: any) {
  return (
    <div className="flex justify-between items-center border-b border-white/5 pb-2 last:border-0 last:pb-0">
      <span className="text-[9px] font-black uppercase text-muted-foreground tracking-widest">{label}</span>
      <span className="text-xs font-bold text-white uppercase">{value}</span>
    </div>
  )
}

function ScoreInfo({ label, impact }: any) {
  return (
    <div className="flex items-center justify-between p-3 rounded-xl bg-white/[0.02] border border-white/5">
      <span className="text-[10px] font-bold uppercase text-muted-foreground">{label}</span>
      <span className="text-[10px] font-black uppercase text-primary">{impact}</span>
    </div>
  )
}
