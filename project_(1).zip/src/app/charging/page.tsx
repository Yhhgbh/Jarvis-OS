
"use client"

import * as React from "react"
import { Zap, Check, Layers, X, Smartphone, Play } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import { useToast } from "@/hooks/use-toast"
import { cn } from "@/lib/utils"
import { Dialog, DialogContent } from "@/components/ui/dialog"

const ANIMATIONS = [
  { id: "trishul", title: "Trishul Energy", category: "Divine", img: "trishul", hint: "trishul glowing" },
  { id: "neon", title: "Neon Ring", category: "Cyber", img: "neon", hint: "neon ring charging" },
  { id: "lightning", title: "Lightning Bolt", category: "Nature", img: "lightning", hint: "lightning effect" },
  { id: "om", title: "Om Vibration", category: "Divine", img: "om", hint: "spiritual symbol" },
  { id: "cyber", title: "Cyber Charge", category: "Premium", img: "cyber", hint: "tech circuit" },
  { id: "minimal", title: "Minimal Flow", category: "Modern", img: "abstract", hint: "minimal dot animation" },
]

export default function ChargingStudioPage() {
  const [selected, setSelected] = React.useState("trishul")
  const [previewOpen, setPreviewOpen] = React.useState(false)
  const { toast } = useToast()

  const handleApply = () => {
    toast({
      title: "Animation Applied",
      description: "Charging effect will trigger when resource connected.",
    })
    setPreviewOpen(false)
  }

  const activeAnim = ANIMATIONS.find(a => a.id === selected) || ANIMATIONS[0]

  return (
    <div className="flex flex-col min-h-screen amoled-gradient px-6 pt-24 space-y-6 pb-24">
      <div className="space-y-1">
        <h1 className="text-2xl font-black tracking-tighter uppercase text-white leading-none">Charging Studio</h1>
        <p className="text-[10px] font-bold text-primary uppercase tracking-[0.3em] mt-1">Premium AMOLED Effects</p>
      </div>

      {/* Hero Preview */}
      <Card className="glass-card border-none overflow-hidden relative aspect-video flex items-center justify-center p-8">
        <div className="absolute inset-0 bg-primary/5" />
        <div className="relative z-10 flex flex-col items-center gap-4 text-center">
          <div className="h-20 w-20 rounded-full bg-primary/20 flex items-center justify-center shadow-2xl shadow-primary/40">
            <Zap className="h-10 w-10 text-primary animate-pulse" />
          </div>
          <div className="space-y-1">
            <h2 className="text-xl font-black uppercase text-white tracking-tighter">{activeAnim.title}</h2>
            <p className="text-[9px] font-bold text-muted-foreground uppercase tracking-widest">Active Template</p>
          </div>
          <Button onClick={() => setPreviewOpen(true)} className="h-10 rounded-xl bg-white text-black font-black uppercase text-[9px] tracking-[0.2em] px-6 gap-2">
            <Play className="h-3 w-3 fill-current" /> Preview Fullscreen
          </Button>
        </div>
      </Card>

      <section className="space-y-4">
        <h3 className="text-[11px] font-black uppercase tracking-widest text-muted-foreground">Select Effect</h3>
        <div className="grid grid-cols-2 gap-3">
          {ANIMATIONS.map((anim) => (
            <Card 
              key={anim.id}
              onClick={() => setSelected(anim.id)}
              className={cn(
                "glass-card border-none overflow-hidden transition-all active:scale-95 cursor-pointer",
                selected === anim.id ? "ring-2 ring-primary bg-primary/10" : "bg-white/[0.02]"
              )}
            >
              <CardContent className="p-3 space-y-3">
                <div className="aspect-square relative rounded-xl overflow-hidden bg-black/40">
                  <Image 
                    src={`https://picsum.photos/seed/${anim.img}/300/300`}
                    alt={anim.title}
                    fill
                    className={cn("object-cover opacity-60", selected === anim.id && "opacity-100 scale-110 transition-transform")}
                  />
                  {selected === anim.id && (
                    <div className="absolute inset-0 bg-primary/20 flex items-center justify-center">
                      <Check className="h-8 w-8 text-white drop-shadow-lg" />
                    </div>
                  )}
                </div>
                <div className="space-y-0.5">
                  <p className="text-[10px] font-black text-white uppercase truncate">{anim.title}</p>
                  <p className="text-[8px] font-bold text-muted-foreground uppercase">{anim.category}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Fullscreen Preview Dialog */}
      <Dialog open={previewOpen} onOpenChange={setPreviewOpen}>
        <DialogContent className="p-0 border-none bg-black max-w-full h-screen rounded-none">
          <div className="relative h-full w-full flex flex-col items-center justify-center">
            <button 
              onClick={() => setPreviewOpen(false)}
              className="absolute top-8 right-8 p-3 rounded-full bg-white/10 text-white z-50"
            >
              <X className="h-5 w-5" />
            </button>

            <div className="relative w-64 h-64 mb-8">
              <div className="absolute inset-0 bg-primary/20 rounded-full blur-3xl animate-pulse" />
              <Image 
                src={`https://picsum.photos/seed/${activeAnim.img}/600/600`}
                alt="Animation Preview"
                fill
                className="object-contain relative z-10"
              />
            </div>

            <div className="text-center space-y-2 mb-12">
              <span className="text-6xl font-black text-white tracking-tighter">85%</span>
              <p className="text-xs font-black text-primary uppercase tracking-[0.5em]">Fast Charging</p>
            </div>

            <div className="absolute bottom-16 left-6 right-6">
              <Button onClick={handleApply} className="w-full h-16 rounded-3xl bg-primary text-white font-black uppercase text-xs tracking-widest shadow-2xl shadow-primary/40">
                Apply Animation
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
