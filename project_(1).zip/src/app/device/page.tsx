"use client"

import * as React from "react"
import { Smartphone, Cpu, Layers, Maximize, RefreshCw, Activity, ShieldAlert, Wifi, Globe } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { useDeviceMetrics } from "@/hooks/useDeviceMetrics"

export default function DeviceCenterPage() {
  const { metrics, deviceInfo, isLoaded } = useDeviceMetrics()
  const [screen, setScreen] = React.useState({ res: "...", refresh: "..." })

  React.useEffect(() => {
    if (typeof window !== 'undefined') {
      setScreen({
        res: `${window.screen.width} x ${window.screen.height}`,
        refresh: "60 Hz" // Baseline
      })
    }
  }, [])

  return (
    <div className="flex flex-col min-h-screen amoled-gradient px-6 pt-24 space-y-6">
      <div className="space-y-1">
        <h1 className="text-2xl font-black tracking-tighter uppercase text-white">Device Center</h1>
        <p className="text-[10px] font-bold text-primary uppercase tracking-[0.3em]">Full Hardware Audit</p>
      </div>

      <section className="space-y-4">
        <h3 className="text-[11px] font-black uppercase tracking-widest text-muted-foreground">System Identity</h3>
        <div className="grid grid-cols-1 gap-3">
          <DetailCard icon={Smartphone} label="Model Name" value={deviceInfo.name} />
          <DetailCard icon={Activity} label="OS Version" value={deviceInfo.os} />
          <DetailCard icon={Layers} label="Architecture" value={typeof navigator !== 'undefined' ? navigator.platform : "ARM"} />
        </div>
      </section>

      <section className="space-y-4">
        <h3 className="text-[11px] font-black uppercase tracking-widest text-muted-foreground">Hardware Specs</h3>
        <div className="grid grid-cols-2 gap-3">
          <DetailCard icon={Cpu} label="RAM Quota" value={metrics.ram ? `${metrics.ram} GB` : "4 GB Est"} />
          <DetailCard icon={Maximize} label="Display" value={screen.res} />
          <DetailCard icon={RefreshCw} label="Refresh" value={screen.refresh} />
          <DetailCard icon={ShieldAlert} label="Security" value="Encrypted" />
        </div>
      </section>

      <section className="space-y-4 pb-12">
        <h3 className="text-[11px] font-black uppercase tracking-widest text-muted-foreground">Environmental</h3>
        <div className="p-5 rounded-3xl bg-white/[0.02] border border-white/5 space-y-4">
          <div className="flex items-center gap-4">
            <div className="p-3 rounded-2xl bg-primary/10 text-primary">
              <Globe className="h-6 w-6" />
            </div>
            <div>
              <p className="text-[10px] font-black uppercase text-muted-foreground">Browser Sandbox</p>
              <p className="text-sm font-bold text-white uppercase">{typeof navigator !== 'undefined' ? navigator.userAgent.split(' ').pop() : "Mobile Browser"}</p>
            </div>
          </div>
          <p className="text-[10px] text-muted-foreground uppercase leading-relaxed font-bold opacity-60">
            Hardware access is verified through official W3C Device APIs. Real-time metrics are recalculated every 30 seconds for accuracy.
          </p>
        </div>
      </section>
    </div>
  )
}

function DetailCard({ icon: Icon, label, value }: any) {
  return (
    <Card className="glass-card border-none">
      <CardContent className="p-5 flex items-center gap-4">
        <div className="p-2 rounded-xl bg-white/5 text-primary">
          <Icon className="h-5 w-5" />
        </div>
        <div className="space-y-0.5">
          <p className="text-[9px] font-black uppercase text-muted-foreground tracking-widest">{label}</p>
          <p className="text-sm font-bold text-white uppercase tracking-tight">{value}</p>
        </div>
      </CardContent>
    </Card>
  )
}
