
"use client"

import * as React from "react"
import { Trash2, HardDrive, Info, Activity } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function StorageAnalyzer() {
  const [total, setTotal] = React.useState<{used: number, quota: number} | null>(null)

  React.useEffect(() => {
    if (navigator.storage && navigator.storage.estimate) {
      navigator.storage.estimate().then(estimate => {
        setTotal({
          used: (estimate.usage || 0) / (1024 ** 3),
          quota: (estimate.quota || 0) / (1024 ** 3)
        })
      })
    }
  }, [])

  const usedPercent = total && total.quota > 0 ? Math.round((total.used / total.quota) * 100) : 0;

  return (
    <Card className="glass-card border-none overflow-hidden">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg flex items-center gap-2 font-black tracking-tighter uppercase">
          <HardDrive className="h-5 w-5 text-primary" />
          Origin Disk Storage
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex flex-col items-center justify-center p-8 rounded-full border-4 border-primary/20 aspect-square w-44 mx-auto relative group">
           <div className="absolute inset-0 bg-primary/5 rounded-full blur-2xl group-hover:bg-primary/10 transition-colors" />
           <p className="text-4xl font-black text-primary leading-none mb-1">{usedPercent}%</p>
           <p className="text-[9px] text-muted-foreground uppercase font-black tracking-widest text-center">Quota Used</p>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between border-b border-white/5 pb-2">
             <p className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">Storage metrics</p>
             <p className="text-[8px] font-bold text-primary uppercase">Factual Data</p>
          </div>
          
          <div className="p-4 rounded-3xl bg-white/[0.02] border border-white/5 flex items-center justify-between">
            <span className="text-[10px] font-black uppercase opacity-40">Available Quota</span>
            <span className="text-[10px] font-bold">{total ? `${total.quota.toFixed(1)} GB` : "Unavailable"}</span>
          </div>

          <div className="p-4 rounded-3xl bg-yellow-500/5 border border-yellow-500/10 flex items-start gap-3">
             <Activity className="h-4 w-4 text-yellow-500 shrink-0 mt-0.5" />
             <p className="text-[10px] text-muted-foreground leading-relaxed">
               Browser privacy policies restrict access to full Android partition data (e.g., WhatsApp, Photos). These metrics reflect the sandbox storage allocated to this application.
             </p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
