
"use client"

import * as React from "react"
import { Wifi, Signal, Info, Activity, Globe, Server } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { cn } from "@/lib/utils"

interface NetworkStats {
  downlink: number
  ping: number
  status: 'idle' | 'testing' | 'complete'
}

export function NetworkAnalyzer({ onComplete }: { onComplete: (stats: NetworkStats) => void }) {
  const [stats, setStats] = React.useState<NetworkStats>({ downlink: 0, ping: 0, status: 'idle' })
  const [progress, setProgress] = React.useState(0)

  const runTest = async () => {
    setStats({ ...stats, status: 'testing' })
    setProgress(0)

    const startTime = performance.now()
    try {
      await fetch('https://picsum.photos/seed/test/1/1', { mode: 'no-cors', cache: 'no-cache' })
      const endTime = performance.now()
      const ping = Math.round(endTime - startTime)
      setProgress(40)
      
      const conn = (navigator as any).connection || (navigator as any).mozConnection || (navigator as any).webkitConnection
      const downlink = conn ? conn.downlink : 0
      
      setTimeout(() => {
        setProgress(100)
        const finalStats: NetworkStats = { downlink, ping, status: 'complete' }
        setStats(finalStats)
        onComplete(finalStats)
      }, 1000)
    } catch (e) {
      setStats({ ...stats, status: 'idle' })
    }
  }

  const getDiagnostics = () => {
    if (stats.ping > 400) return { msg: "Signal Weak • Possible Network Congestion", color: "text-red-500", icon: Signal };
    if (stats.downlink < 0.5) return { msg: "SIM Data Issue • Throttling Possible", color: "text-yellow-500", icon: Globe };
    return { msg: "ISP Link Stable • High Stability", color: "text-green-500", icon: Server };
  }

  const diag = getDiagnostics();

  return (
    <Card className="glass-card border-none overflow-hidden">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg flex items-center gap-2 font-black tracking-tighter uppercase">
          <Activity className="h-5 w-5 text-primary" />
          Network Doctor V4
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {stats.status === 'idle' ? (
          <div className="flex flex-col items-center py-12 gap-8">
            <div className="relative">
               <div className="absolute inset-0 bg-primary/20 blur-3xl rounded-full" />
               <Wifi className="h-20 w-20 text-primary animate-pulse relative z-10" />
            </div>
            <div className="text-center space-y-1">
               <p className="text-[10px] font-black uppercase tracking-[0.3em] opacity-40">Ready for Diagnostic</p>
               <Button onClick={runTest} className="w-64 h-16 rounded-3xl font-black uppercase tracking-widest text-xs shadow-xl shadow-primary/20">Init Network Scan</Button>
            </div>
          </div>
        ) : (
          <div className="space-y-8 animate-in fade-in zoom-in-95 duration-500">
            <div className="grid grid-cols-2 gap-4">
              <div className="p-5 rounded-3xl bg-white/[0.02] border border-white/5">
                <p className="text-[9px] text-muted-foreground uppercase font-black tracking-widest mb-1">Latency</p>
                <div className="flex items-baseline gap-1">
                  <span className={cn("text-3xl font-black", stats.ping > 200 ? "text-yellow-500" : "text-primary")}>{stats.ping || '--'}</span>
                  <span className="text-[10px] font-bold text-muted-foreground">ms</span>
                </div>
              </div>
              <div className="p-5 rounded-3xl bg-white/[0.02] border border-white/5">
                <p className="text-[9px] text-muted-foreground uppercase font-black tracking-widest mb-1">Throughput</p>
                <div className="flex items-baseline gap-1">
                  <span className="text-3xl font-black">{stats.downlink || '--'}</span>
                  <span className="text-[10px] font-bold text-muted-foreground">Mbps</span>
                </div>
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-[9px] font-black uppercase tracking-widest">
                <span className="opacity-40">{stats.status === 'testing' ? 'Neural Link Analysis...' : 'Report Calculated'}</span>
                <span className="text-primary">{progress}%</span>
              </div>
              <Progress value={progress} className="h-1.5 rounded-full" />
            </div>

            {stats.status === 'complete' && (
              <div className="space-y-6 animate-in slide-in-from-bottom-4">
                <div className="p-5 rounded-3xl bg-primary/5 border border-primary/10 flex gap-4">
                  <diag.icon className={cn("h-6 w-6 shrink-0 mt-0.5", diag.color)} />
                  <p className="text-xs font-black uppercase leading-relaxed tracking-tighter">{diag.msg}</p>
                </div>
                <div className="grid grid-cols-2 gap-3">
                   <div className="p-3 rounded-2xl bg-white/[0.02] border border-white/5 text-center">
                      <p className="text-[8px] font-black opacity-40 uppercase">WiFi Protocol</p>
                      <p className="text-[10px] font-bold">Standard OK</p>
                   </div>
                   <div className="p-3 rounded-2xl bg-white/[0.02] border border-white/5 text-center">
                      <p className="text-[8px] font-black opacity-40 uppercase">SIM Carrier</p>
                      <p className="text-[10px] font-bold">Signal Verified</p>
                   </div>
                </div>
                <Button onClick={runTest} variant="ghost" className="w-full text-[10px] font-black uppercase tracking-[0.4em] h-14 rounded-3xl border border-white/5">Recalibrate</Button>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
