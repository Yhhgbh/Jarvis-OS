"use client"

import * as React from "react"
import { AlertCircle, CheckCircle2, ChevronRight, Info, Zap, Wifi } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

export function ActionCenter({ metrics, network }: { metrics: any, network: any }) {
  const issues = React.useMemo(() => {
    if (!metrics || !network) return []
    const list = []
    
    // Factual Threshold Checks
    if (metrics.storage !== null && metrics.storage > 95) {
      list.push({ 
        icon: AlertCircle, 
        label: "Storage Partition Limit", 
        fix: "Free Space",
        desc: `Storage is at ${metrics.storage}% capacity. System performance may degrade severely.`,
        steps: ["Navigate to System > Storage", "Clear large temporary cache files", "Uninstall redundant browser-origin apps"]
      })
    }

    if (metrics.battery !== null && metrics.battery < 15) {
      list.push({ 
        icon: Zap, 
        label: "Power Supply Critical", 
        fix: "Connect Power",
        desc: `Battery level is at ${metrics.battery}%. System integrity requires stable power.`,
        steps: ["Connect a verified charger immediately", "Enable Power Saving Mode", "Reduce screen brightness"]
      })
    }

    if (network && network.ping > 1200) {
      list.push({ 
        icon: Wifi, 
        label: "High Network Latency", 
        fix: "Switch Network",
        desc: `Network response time is ${network.ping}ms. This is far below stability standards.`,
        steps: ["Switch to a stable WiFi network", "Toggle Airplane Mode to reset radio", "Contact your ISP if using cellular data"]
      })
    }
    
    return list
  }, [metrics, network])

  if (issues.length === 0) {
    return (
      <Card className="glass-card border-none bg-green-500/5 relative overflow-hidden">
        <CardContent className="p-4 flex items-center gap-3">
          <CheckCircle2 className="h-5 w-5 text-green-500 shrink-0" />
          <div className="space-y-0.5">
            <p className="text-[10px] font-black uppercase tracking-widest text-green-500">SYSTEM STABLE</p>
            <p className="text-[10px] font-bold opacity-60 uppercase">All hardware parameters verified</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="glass-card border-none bg-destructive/5 animate-in zoom-in-95 duration-500 relative">
      <CardContent className="p-4 space-y-4">
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <p className="text-[10px] font-black uppercase tracking-[0.2em] text-destructive">SYSTEM ALERTS</p>
            <h3 className="text-sm font-black text-destructive/90 uppercase tracking-tighter">
              {issues.length} HARDWARE {issues.length > 1 ? 'ALERTS' : 'ALERT'} FOUND
            </h3>
          </div>
        </div>
        
        <div className="space-y-2">
          {issues.map((issue, i) => (
            <Dialog key={i}>
              <DialogTrigger asChild>
                <div className="flex items-center justify-between p-3 rounded-xl bg-black/40 border border-white/5 group active:bg-black/60 transition-all cursor-pointer">
                  <div className="flex items-center gap-3 overflow-hidden">
                    <issue.icon className="h-4 w-4 text-destructive shrink-0" />
                    <span className="text-[10px] font-bold truncate uppercase">{issue.label}</span>
                  </div>
                  <div className="flex items-center gap-1 text-[8px] font-black uppercase text-primary shrink-0">
                    {issue.fix} <ChevronRight className="h-3 w-3" />
                  </div>
                </div>
              </DialogTrigger>
              <DialogContent className="glass-card border-none text-foreground max-w-[90vw] rounded-3xl">
                <DialogHeader>
                  <DialogTitle className="text-lg font-black uppercase tracking-tighter flex items-center gap-2">
                    <Info className="h-5 w-5 text-primary" /> Resolution Guide
                  </DialogTitle>
                </DialogHeader>
                <div className="space-y-6 pt-4">
                  <div className="space-y-2">
                    <h4 className="text-[10px] font-black uppercase text-primary tracking-widest">{issue.label}</h4>
                    <p className="text-xs font-medium leading-relaxed opacity-80">{issue.desc}</p>
                  </div>
                  <div className="space-y-3">
                    <p className="text-[9px] font-black uppercase opacity-40">Recommended Action Steps</p>
                    <div className="space-y-2">
                      {issue.steps.map((step, idx) => (
                        <div key={idx} className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/5 text-[10px] font-bold uppercase">
                          <span className="h-5 w-5 rounded-full bg-primary/20 text-primary flex items-center justify-center text-[8px]">{idx + 1}</span>
                          {step}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
