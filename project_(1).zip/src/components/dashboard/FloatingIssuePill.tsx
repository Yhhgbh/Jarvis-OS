"use client"

/**
 * This component has been neutralized to prevent accidental issue rendering.
 * All issues are now handled statically via the ActionCenter component.
 */
export function FloatingIssuePill() {
  return null;
}
