
'use client';

import React, { useState, useEffect, useRef } from 'react';
import { X, Plus, Mic, Send, Zap, Activity, Info, ShieldAlert, Cpu, HardDrive, Wifi, Settings } from 'lucide-react';
import Groq from 'groq-sdk';
import { cn } from '@/lib/utils';

// JARVIS OS v7.0 - STARK HUD CORE
const SYSTEM_PROMPT = `You are JARVIS OS. Provide exact, technical, and professional responses. No hashtags. No conversational filler. No labels. Use concise markdown. Today's date is ${new Date().toLocaleDateString()}.`;

export default function JarvisAssistant() {
  // View State: 'chat' | 'dashboard'
  const [view, setView] = useState<'chat' | 'dashboard'>('chat');
  const [input, setInput] = useState('');
  const [history, setHistory] = useState<{ role: 'user' | 'assistant', content: string }[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [apiKey, setApiKey] = useState('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');
  const [model, setModel] = useState('llama-3.3-70b-versatile');
  
  // System Telemetry State
  const [stats, setStats] = useState({
    battery: '--%',
    ram: '-- GB',
    memory: '-- / -- GB',
    cache: '0 MB',
    speed: '-- Mbps',
    latency: '0ms'
  });

  const scrollRef = useRef<HTMLDivElement>(null);

  // Initialize: Setup Chat and Telemetry
  useEffect(() => {
    // Initial Greeting as per spec
    setHistory([{ role: 'assistant', content: 'Namaste, main Jarvis hoon. Aaj main aapki kaise madad kar sakta hoon?' }]);
    
    // Telemetry Polling
    const pollStats = async () => {
      // Battery
      if ('getBattery' in navigator) {
        const bat = await (navigator as any).getBattery();
        setStats(prev => ({ ...prev, battery: `${Math.round(bat.level * 100)}%` }));
      }
      
      // RAM
      const ram = (navigator as any).deviceMemory || 8;
      setStats(prev => ({ ...prev, ram: `${ram} GB` }));

      // Storage/Memory
      if (navigator.storage && navigator.storage.estimate) {
        const est = await navigator.storage.estimate();
        const used = ((est.usage || 0) / (1024 ** 3)).toFixed(1);
        const total = ((est.quota || 0) / (1024 ** 3)).toFixed(1);
        setStats(prev => ({ ...prev, memory: `${used} / ${total} GB` }));
      }

      // Network speed (Downlink)
      const conn = (navigator as any).connection;
      if (conn) {
        setStats(prev => ({ ...prev, speed: `${conn.downlink} Mbps` }));
      }
    };

    pollStats();
    const interval = setInterval(pollStats, 10000);
    return () => clearInterval(interval);
  }, []);

  // Scroll to bottom on new messages
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [history, isLoading]);

  // Neural Execution Logic
  const executeCommand = async (command?: string) => {
    const cmd = (command || input).trim();
    if (!cmd || isLoading) return;

    // Reset input
    if (!command) setInput('');

    // Persistence Check: Voice commands (passed via arg) don't save to history
    const isVoice = !!command;
    const newHistory = [...history, { role: 'user' as const, content: cmd }];
    
    if (!isVoice) {
      setHistory(newHistory);
    }

    setIsLoading(true);

    try {
      const groq = new Groq({ apiKey, dangerouslyAllowBrowser: true });
      const chatCompletion = await groq.chat.completions.create({
        messages: [{ role: 'system', content: SYSTEM_PROMPT }, ...newHistory],
        model: model,
      });

      const response = chatCompletion.choices[0]?.message?.content || 'Link Failure.';

      if (isVoice) {
        speakResponse(response);
      } else {
        setHistory(prev => [...prev, { role: 'assistant' as const, content: response }]);
        speakResponse(response);
      }
    } catch (error) {
      console.error('Neural Handshake Failure:', error);
      const errRes = 'Neural Handshake Failure. Check API Key.';
      if (isVoice) speakResponse(errRes);
      else setHistory(prev => [...prev, { role: 'assistant' as const, content: errRes }]);
    } finally {
      setIsLoading(false);
    }
  };

  // Voice Core
  const startVoiceCapture = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('System Error: Speech recognition hardware not detected.');
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      executeCommand(transcript);
    };
    recognition.start();
  };

  const speakResponse = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.0;
      utterance.pitch = 1.0;
      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <div className="fixed inset-0 z-[1000] bg-[#050505] text-[#00f2ff] font-mono flex flex-col overflow-hidden animate-in fade-in duration-500">
      
      {/* HUD HEADER - Minimized Branding */}
      <header className="px-6 py-4 flex justify-between items-center border-b border-[#00f2ff]/10">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4" />
          <span className="text-xs font-black uppercase tracking-[0.4em]">Jarvis OS v7.0</span>
        </div>
        <button 
          onClick={() => window.dispatchEvent(new CustomEvent('close-jarvis'))}
          className="p-1 opacity-40 hover:opacity-100 transition-opacity"
        >
          <X className="w-5 h-5" />
        </button>
      </header>

      {/* VIEWPORT: Chat or Dashboard */}
      <main className="flex-1 overflow-hidden relative">
        {view === 'chat' ? (
          <div ref={scrollRef} className="h-full overflow-y-auto px-6 py-8 space-y-6 scrollbar-hide">
            {history.map((msg, i) => (
              <div key={i} className={cn(
                "flex flex-col animate-in slide-in-from-bottom-2 duration-300",
                msg.role === 'user' ? "items-end" : "items-start"
              )}>
                <div className={cn(
                  "max-w-[85%] p-4 rounded-xl text-sm leading-relaxed border",
                  msg.role === 'user' 
                    ? "bg-[#00f2ff]/5 border-[#00f2ff]/20 text-white" 
                    : "bg-white/[0.02] border-white/5 text-[#00f2ff] shadow-[0_0_15px_rgba(0,242,255,0.05)]"
                )}>
                  {msg.content}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex items-center gap-2 opacity-40 animate-pulse text-[10px] uppercase tracking-widest">
                <Zap className="w-3 h-3" /> Processing Neural Request...
              </div>
            )}
          </div>
        ) : (
          <div className="h-full overflow-y-auto px-6 py-8 space-y-8 animate-in zoom-in-95 duration-300">
            {/* Real-time System Stats */}
            <section className="space-y-4">
              <h3 className="text-[10px] font-black uppercase tracking-widest opacity-40 flex items-center gap-2">
                <Settings className="w-3 h-3" /> System Registers
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <StatCard icon={Zap} label="Supply" value={stats.battery} />
                <StatCard icon={Cpu} label="RAM" value={stats.ram} />
                <StatCard icon={HardDrive} label="Disk" value={stats.memory} />
                <StatCard icon={Wifi} label="Link" value={stats.speed} />
              </div>
            </section>

            {/* Configuration Panel */}
            <section className="space-y-4">
              <h3 className="text-[10px] font-black uppercase tracking-widest opacity-40 flex items-center gap-2">
                <Info className="w-3 h-3" /> Configuration
              </h3>
              <div className="space-y-4 bg-white/[0.02] border border-white/5 p-6 rounded-2xl">
                <div className="space-y-2">
                  <label className="text-[8px] font-black uppercase tracking-widest opacity-40">Groq API Key</label>
                  <input 
                    type="password"
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    className="w-full bg-black/40 border border-[#00f2ff]/20 rounded-xl px-4 h-12 text-xs focus:border-[#00f2ff] outline-none"
                    placeholder="Enter Key..."
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[8px] font-black uppercase tracking-widest opacity-40">Neural Model</label>
                  <select 
                    value={model}
                    onChange={(e) => setModel(e.target.value)}
                    className="w-full bg-black/40 border border-[#00f2ff]/20 rounded-xl px-4 h-12 text-xs focus:border-[#00f2ff] outline-none appearance-none"
                  >
                    <option value="llama-3.3-70b-versatile">Llama 3.3 70B (Versatile)</option>
                    <option value="llama3-70b-8192">Llama 3 70B (Standard)</option>
                    <option value="mixtral-8x7b-32768">Mixtral 8x7B</option>
                  </select>
                </div>
              </div>
            </section>
          </div>
        )}
      </main>

      {/* HUD DOCK - Bottom Permanent Navigation */}
      <footer className="p-6 pb-10 border-t border-white/5 bg-[#050505]/80 backdrop-blur-md">
        <div className="flex gap-3 items-center max-w-lg mx-auto">
          {/* Dashboard Trigger */}
          <button 
            onClick={() => setView(view === 'chat' ? 'dashboard' : 'chat')}
            className={cn(
              "h-14 w-14 rounded-2xl border transition-all flex items-center justify-center",
              view === 'dashboard' ? "bg-[#00f2ff] text-black border-[#00f2ff]" : "bg-white/5 border-white/10 text-[#00f2ff]"
            )}
          >
            <Plus className={cn("w-6 h-6 transition-transform", view === 'dashboard' && "rotate-45")} />
          </button>

          {/* Chat Input */}
          <div className="flex-1 relative">
            <input 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && executeCommand()}
              placeholder="Execute neural command..."
              className="w-full bg-white/[0.03] border border-[#00f2ff]/20 rounded-2xl px-5 h-14 text-sm focus:outline-none focus:border-[#00f2ff] transition-all text-white placeholder:opacity-20"
            />
          </div>

          {/* Execution & Voice Actions */}
          <div className="flex gap-2">
            <button 
              onClick={() => executeCommand()}
              className="h-14 w-14 rounded-2xl bg-[#00f2ff]/10 border border-[#00f2ff]/20 flex items-center justify-center text-[#00f2ff] hover:bg-[#00f2ff]/20 transition-all"
            >
              <Send className="w-5 h-5" />
            </button>
            <button 
              onClick={startVoiceCapture}
              className={cn(
                "h-14 w-14 rounded-2xl border flex items-center justify-center transition-all",
                isListening 
                  ? "bg-[#00f2ff] text-black shadow-[0_0_30px_#00f2ff] animate-pulse" 
                  : "bg-white/5 border-white/10 text-[#00f2ff]"
              )}
            >
              <Mic className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Neural Footer */}
        <div className="mt-6 text-center">
          <p className="text-[9px] font-black uppercase tracking-[0.5em] opacity-20">Created by Tarun Joshi</p>
        </div>
      </footer>

      <style jsx>{`
        .scrollbar-hide::-webkit-scrollbar { display: none; }
        .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>
    </div>
  );
}

function StatCard({ icon: Icon, label, value }: { icon: any, label: string, value: string }) {
  return (
    <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/5 space-y-1">
      <div className="flex items-center gap-2 opacity-40">
        <Icon className="w-3 h-3" />
        <span className="text-[8px] font-black uppercase tracking-widest">{label}</span>
      </div>
      <p className="text-sm font-bold text-white uppercase tracking-tight">{value}</p>
    </div>
  );
}
