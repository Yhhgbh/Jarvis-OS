"use client"

import * as React from "react"
import { ShieldCheck, AlertTriangle, XCircle, Info } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip"

interface Metrics {
  ram: number | null;
  storage: number | null;
  battery: number | null;
}

export function HealthOverview({ score, status, metrics }: { score: number, status: string, metrics: Metrics }) {
  const getStatusIcon = () => {
    if (score >= 80) return <ShieldCheck className="h-3 w-3 sm:h-4 sm:w-4 text-green-500" />
    if (score >= 50) return <AlertTriangle className="h-3 w-3 sm:h-4 sm:w-4 text-yellow-500" />
    return <XCircle className="h-3 w-3 sm:h-4 sm:w-4 text-destructive" />
  }

  return (
    <Card className="glass-card border-none overflow-hidden">
      <CardContent className="p-4 sm:p-6 space-y-4 sm:space-y-6">
        <div className="flex items-center justify-between">
          <div className="space-y-0.5 sm:space-y-1">
            <div className="flex items-center gap-2">
              <p className="text-[8px] sm:text-[10px] font-black uppercase tracking-[0.3em] opacity-40">Integrity Score</p>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger>
                    <Info className="h-3 w-3 opacity-20" />
                  </TooltipTrigger>
                  <TooltipContent className="glass-card border-none p-4 max-w-xs">
                    <div className="space-y-2 text-[9px] font-bold uppercase tracking-widest">
                      <p className="text-primary border-b border-white/5 pb-1">Calculation Protocol:</p>
                      <div className="grid grid-cols-2 gap-2">
                        <span>Battery &lt; 20%</span> <span className="text-destructive">-15 PTS</span>
                        <span>Latency &gt; 800ms</span> <span className="text-destructive">-25 PTS</span>
                        <span>Storage &gt; 95%</span> <span className="text-destructive">-20 PTS</span>
                        <span>API Restricted</span> <span className="text-yellow-500">-5 PTS</span>
                      </div>
                    </div>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
            <h2 className="text-4xl sm:text-5xl font-black tracking-tighter leading-none">
              {score}<span className="text-xs opacity-20 ml-1">/100</span>
            </h2>
          </div>
          <div className="flex flex-col items-end gap-1">
            <div className={cn(
              "flex items-center gap-1 sm:gap-1.5 px-2 sm:px-3 py-0.5 sm:py-1 rounded-full text-[8px] sm:text-[9px] font-black uppercase tracking-widest",
              score >= 80 ? "bg-green-500/10 text-green-500" : score >= 50 ? "bg-yellow-500/10 text-yellow-500" : "bg-destructive/10 text-destructive"
            )}>
              {getStatusIcon()}
              {status}
            </div>
            <p className="text-[7px] sm:text-[8px] font-bold opacity-30 uppercase">Factual Hardware Sync</p>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-1.5 sm:gap-2">
          <StatBox 
            label="RAM" 
            value={metrics.ram ? `${metrics.ram}GB` : "Unavailable"} 
            status={metrics.ram ? "Active" : "Restricted"} 
          />
          <StatBox 
            label="DISK" 
            value={metrics.storage !== null ? `${metrics.storage}%` : "Restricted"} 
            status={metrics.storage !== null ? (metrics.storage > 95 ? "Limit" : "Normal") : "Protected"} 
          />
          <StatBox 
            label="POWER" 
            value={metrics.battery !== null ? `${metrics.battery}%` : "Restricted"} 
            status={metrics.battery !== null ? (metrics.battery < 20 ? "Low" : "Verified") : "Protected"} 
          />
        </div>
      </CardContent>
    </Card>
  )
}

function StatBox({ label, value, status }: { label: string, value: string, status: string }) {
  const isWarning = status === "Critical" || status === "Full" || status === "Low" || status === "Limit";
  const isRestricted = status === "Restricted" || status === "Protected";

  return (
    <div className="bg-white/[0.03] border border-white/5 p-2 sm:p-3 rounded-xl sm:rounded-2xl flex flex-col gap-0.5 sm:gap-1">
      <span className="text-[7px] sm:text-[8px] font-black uppercase opacity-40 truncate">{label}</span>
      <span className="text-xs sm:text-sm font-black tracking-tight truncate">{value}</span>
      <span className={cn(
        "text-[6px] sm:text-[7px] font-bold uppercase truncate", 
        isWarning ? "text-destructive" : isRestricted ? "text-yellow-500" : "text-primary"
      )}>{status}</span>
    </div>
  )
}
