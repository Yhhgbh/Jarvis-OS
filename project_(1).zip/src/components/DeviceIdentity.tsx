
"use client"

import * as React from "react"
import { Smartphone, Info, Globe, Layers, Maximize, RefreshCw } from "lucide-react"

export function DeviceIdentity() {
  const [deviceInfo, setDeviceInfo] = React.useState({
    os: "Loading...",
    platform: "Loading...",
    browser: "Loading...",
    memory: "Loading...",
    resolution: "Loading...",
    refreshRate: "Calculating...",
  })

  React.useEffect(() => {
    const ua = window.navigator.userAgent
    let os = "Android OS"
    if (ua.indexOf("iPhone") !== -1 || ua.indexOf("iPad") !== -1) os = "iOS"
    else if (ua.indexOf("Windows") !== -1) os = "Windows"
    else if (ua.indexOf("Mac OS") !== -1) os = "macOS"

    // Refresh rate estimation
    let start: number | null = null;
    let frames = 0;
    const checkFPS = (timestamp: number) => {
      if (!start) start = timestamp;
      frames++;
      if (timestamp - start < 1000) {
        requestAnimationFrame(checkFPS);
      } else {
        setDeviceInfo(prev => ({ ...prev, refreshRate: `${frames} Hz` }));
      }
    };
    requestAnimationFrame(checkFPS);

    setDeviceInfo({
      os,
      platform: navigator.platform,
      browser: navigator.userAgent.split(' ').pop() || 'Unknown',
      memory: (navigator as any).deviceMemory ? `${(navigator as any).deviceMemory} GB` : 'Unavailable',
      resolution: `${window.screen.width} x ${window.screen.height}`,
      refreshRate: "Calculating..."
    })
  }, [])

  const InfoItem = ({ icon: Icon, label, value }: { icon: any, label: string, value: string }) => (
    <div className="flex items-center gap-3 p-4 rounded-2xl border border-white/5 bg-white/[0.02]">
      <div className="p-2 rounded-xl bg-muted text-muted-foreground">
        <Icon className="h-4 w-4" />
      </div>
      <div className="flex-1 overflow-hidden">
        <p className="text-[9px] font-black uppercase tracking-wider text-muted-foreground opacity-50">{label}</p>
        <p className="text-xs font-bold truncate tracking-tight">{value}</p>
      </div>
    </div>
  )

  return (
    <div className="grid grid-cols-2 gap-3">
      <InfoItem icon={Smartphone} label="System" value={deviceInfo.os} />
      <InfoItem icon={Layers} label="Architecture" value={deviceInfo.platform} />
      <InfoItem icon={Maximize} label="Display Res" value={deviceInfo.resolution} />
      <InfoItem icon={RefreshCw} label="Refresh Rate" value={deviceInfo.refreshRate} />
    </div>
  )
}
