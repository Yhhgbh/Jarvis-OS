
"use client"

import * as React from "react"
import { Hammer, ArrowRight, CheckCircle2 } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

interface FixMyPhoneProps {
  metrics: { ram: number | null; storage: number | null; battery: number | null } | null;
  networkStats: { ping: number; downlink: number } | null;
}

export function FixMyPhone({ metrics, networkStats }: FixMyPhoneProps) {
  const [isResolved, setIsResolved] = React.useState(false);

  const issues = React.useMemo(() => {
    if (!metrics) return [];
    const list = [];
    if (metrics.battery !== null && metrics.battery < 20) {
      list.push({ label: "Power Level Critical", action: "Connect Charger" });
    }
    if (metrics.storage !== null && metrics.storage > 90) {
      list.push({ label: "Storage Limit Reached", action: "Clear Browser Cache" });
    }
    if (networkStats && networkStats.ping > 400) {
      list.push({ label: "Network Instability", action: "Verify Connectivity" });
    }
    return list;
  }, [metrics, networkStats]);

  if (issues.length === 0) return null;

  return (
    <Card className="border-none bg-primary/10 overflow-hidden shadow-xl animate-in zoom-in-95 duration-500">
      <CardContent className="p-6">
        <div className="flex items-center gap-4 mb-6">
          <div className="h-10 w-10 rounded-2xl bg-primary text-primary-foreground flex items-center justify-center">
            <Hammer className="h-5 w-5" />
          </div>
          <div>
            <h3 className="text-[10px] font-black uppercase tracking-[0.3em] leading-none mb-1">System Action required</h3>
            <p className="text-[9px] text-muted-foreground font-black uppercase tracking-tighter">{issues.length} Hardware conditions detected</p>
          </div>
        </div>

        <div className="space-y-3">
          {issues.map((issue, idx) => (
            <div key={idx} className="flex items-center justify-between p-4 rounded-2xl bg-black/40 border border-white/5">
              <span className="text-[10px] font-black uppercase tracking-widest">{issue.label}</span>
              <div className="flex items-center gap-2 text-[9px] font-black uppercase text-primary">
                 {issue.action} <ArrowRight className="h-3 w-3" />
              </div>
            </div>
          ))}
        </div>

        <button 
          className="w-full mt-6 bg-primary hover:bg-primary/90 text-primary-foreground h-12 rounded-2xl font-black uppercase tracking-widest text-xs shadow-lg flex items-center justify-center"
          onClick={() => setIsResolved(true)}
        >
          {isResolved ? (
            <span className="flex items-center gap-2"><CheckCircle2 className="h-4 w-4" /> Conditions Acknowledged</span>
          ) : (
            <span>Analyze resolution steps</span>
          )}
        </button>
      </CardContent>
    </Card>
  );
}
