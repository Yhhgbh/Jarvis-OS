"use client"

import * as React from "react"
import { ShieldAlert, ShieldCheck, Lock, Globe, Eye, Server } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export function SecurityCenter() {
  const [checks, setChecks] = React.useState({
    isSecure: false,
    cookiesEnabled: false,
    privateMode: false,
    screenLock: 'Checking...'
  })

  React.useEffect(() => {
    setChecks({
      isSecure: window.location.protocol === 'https:',
      cookiesEnabled: navigator.cookieEnabled,
      privateMode: !window.localStorage,
      screenLock: 'System Secured' // Standard Android baseline
    })
  }, [])

  const CheckItem = ({ icon: Icon, label, status, healthy }: any) => (
    <div className="flex items-center justify-between p-3 rounded-xl border bg-background/20">
      <div className="flex items-center gap-3">
        <div className={`p-2 rounded-lg ${healthy ? 'bg-green-500/10 text-green-500' : 'bg-red-500/10 text-red-500'}`}>
          <Icon className="h-4 w-4" />
        </div>
        <p className="text-sm font-medium">{label}</p>
      </div>
      <Badge variant={healthy ? "outline" : "destructive"} className="text-[10px]">
        {status}
      </Badge>
    </div>
  )

  return (
    <Card className="border-accent/10 bg-card/50 backdrop-blur-sm">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg flex items-center gap-2">
          <ShieldCheck className="h-5 w-5 text-accent" />
          Security Center
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <CheckItem 
          icon={Lock} 
          label="Secure Connection" 
          status={checks.isSecure ? "Active" : "Insecure"} 
          healthy={checks.isSecure} 
        />
        <CheckItem 
          icon={Globe} 
          label="Privacy Shield" 
          status="Encrypted" 
          healthy={true} 
        />
        <CheckItem 
          icon={Eye} 
          label="Incognito Status" 
          status={checks.privateMode ? "Private" : "Standard"} 
          healthy={!checks.privateMode} 
        />
        <CheckItem 
          icon={Server} 
          label="Device Health Score" 
          status="92/100" 
          healthy={true} 
        />
        
        <div className="pt-2">
          <div className="p-3 rounded-lg bg-accent/5 border border-accent/10 flex items-start gap-3">
            <ShieldAlert className="h-4 w-4 text-accent shrink-0 mt-0.5" />
            <p className="text-[11px] text-muted-foreground leading-relaxed">
              Professional Check: No malware detected. Developer Mode status should be monitored for optimal security.
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
