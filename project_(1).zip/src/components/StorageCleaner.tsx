"use client"

import * as React from "react"
import { Trash2, FileText, Download, MessageSquare, ShieldCheck, ChevronRight } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

export function StorageCleaner() {
  const [storageData, setStorageData] = React.useState<{
    used: number;
    quota: number;
    percent: number;
  } | null>(null)

  React.useEffect(() => {
    if (navigator.storage && navigator.storage.estimate) {
      navigator.storage.estimate().then(estimate => {
        const used = (estimate.usage || 0) / (1024 * 1024 * 1024)
        const quota = (estimate.quota || 1) / (1024 * 1024 * 1024)
        setStorageData({
          used,
          quota,
          percent: Math.round((used / quota) * 100)
        })
      })
    }
  }, [])

  const suggestions = [
    { icon: MessageSquare, label: "WhatsApp Media", size: "3.2 GB", desc: "Redundant videos and shared media", safe: true },
    { icon: Download, label: "Downloads", size: "1.8 GB", desc: "Old installers and documents", safe: true },
    { icon: FileText, label: "Large Files", size: "4.5 GB", desc: "Files larger than 100MB", safe: false },
  ]

  return (
    <Card className="border-accent/10 bg-card/50 backdrop-blur-sm">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg flex items-center gap-2">
          <Trash2 className="h-5 w-5 text-accent" />
          Smart Storage Cleaner
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="p-3 rounded-lg bg-accent/5 border border-accent/10 flex items-center gap-3">
          <ShieldCheck className="h-8 w-8 text-accent shrink-0" />
          <div className="flex-1">
            <p className="text-sm font-semibold">Safe Cleanup Active</p>
            <p className="text-xs text-muted-foreground">No essential system files will be removed.</p>
          </div>
        </div>

        <div className="space-y-3">
          {suggestions.map((item, idx) => (
            <div key={idx} className="flex items-center justify-between p-3 rounded-xl border bg-background/40 hover:bg-background/60 transition-colors">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-muted text-muted-foreground">
                  <item.icon className="h-4 w-4" />
                </div>
                <div>
                  <p className="text-sm font-medium leading-none mb-1">{item.label}</p>
                  <p className="text-[10px] text-muted-foreground">{item.desc}</p>
                </div>
              </div>
              <div className="text-right">
                <Badge variant={item.safe ? "outline" : "secondary"} className="text-[10px] mb-1">
                  {item.size}
                </Badge>
                <div className="flex items-center gap-1 text-[10px] font-bold text-accent cursor-pointer hover:underline uppercase tracking-tighter">
                  View <ChevronRight className="h-3 w-3" />
                </div>
              </div>
            </div>
          ))}
        </div>

        <Button className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-bold py-6">
          Analyze Full Device Storage
        </Button>
      </CardContent>
    </Card>
  )
}
