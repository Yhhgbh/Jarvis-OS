"use client"

import * as React from "react"
import { Battery, Zap, Activity } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { cn } from "@/lib/utils"

export function BatteryAnalyzer() {
  const [battery, setBattery] = React.useState<{
    level: number;
    charging: boolean;
    chargingTime: number;
    dischargingTime: number;
  } | null>(null)

  React.useEffect(() => {
    if ('getBattery' in navigator) {
      (navigator as any).getBattery().then((bat: any) => {
        const update = () => setBattery({
          level: bat.level,
          charging: bat.charging,
          chargingTime: bat.chargingTime,
          dischargingTime: bat.dischargingTime,
        })
        update()
        bat.addEventListener('levelchange', update)
        bat.addEventListener('chargingchange', update)
      })
    }
  }, [])

  if (!battery) return (
    <Card className="glass-card border-none p-6 text-center">
      <p className="text-[10px] font-black uppercase opacity-40">Battery API Not Supported</p>
    </Card>
  )

  const levelPercent = Math.round(battery.level * 100)
  // Low battery is a warning, not a hardware fault
  const isWarning = levelPercent < 20

  return (
    <Card className="glass-card border-none overflow-hidden">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg flex items-center gap-2 font-black tracking-tighter uppercase">
          <Activity className="h-5 w-5 text-green-500" />
          Power Analysis
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-8">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-5xl font-black tracking-tighter">{levelPercent}%</span>
            <p className="text-[10px] text-muted-foreground uppercase font-black tracking-[0.2em]">
              {battery.charging ? "Resource Connected" : "On Battery Supply"}
            </p>
          </div>
          <div className={cn(
            "h-16 w-16 rounded-3xl flex items-center justify-center transition-all shadow-xl",
            battery.charging ? 'bg-green-500/20 text-green-500' : 'bg-primary/10 text-primary'
          )}>
            {battery.charging ? <Zap className="h-8 w-8 animate-pulse" /> : <Battery className="h-8 w-8" />}
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex justify-between text-[10px] font-black uppercase tracking-widest">
            <span className="opacity-40">Physical Charge</span>
            <span className={!isWarning ? "text-green-500" : "text-yellow-500"}>
              {!isWarning ? "Verified" : "Low Energy"}
            </span>
          </div>
          <Progress value={levelPercent} className={cn("h-2 rounded-full", isWarning ? "[&>div]:bg-yellow-500" : "[&>div]:bg-green-500")} />
        </div>

        <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/5 space-y-2">
          <div className="flex justify-between items-center text-[9px] font-black uppercase opacity-50">
            <span>Power State</span>
            <span>{battery.charging ? "Charging" : "Discharging"}</span>
          </div>
          <p className="text-[10px] text-muted-foreground leading-relaxed">
            Note: Battery health (Cycles/Health %) is restricted for third-party web access to prevent device fingerprinting.
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
