"use client"

import * as React from "react"
import { FileText, Download, CheckCircle2, Clock } from "lucide-react"

interface HealthReportProps {
  metrics: { ram: number | null; storage: number | null; battery: number | null } | null;
  networkStats: { ping: number; downlink: number } | null;
}

export function HealthReport({ metrics, networkStats }: HealthReportProps) {
  const [timestamp, setTimestamp] = React.useState<string | null>(null);

  React.useEffect(() => {
    setTimestamp(new Date().toLocaleString());
  }, []);

  return (
    <div className="space-y-6 py-4">
      <div className="flex items-center justify-between border-b border-white/5 pb-4">
        <div className="flex items-center gap-2">
          <Clock className="h-4 w-4 text-primary" />
          <span className="text-[10px] font-black uppercase tracking-widest opacity-50">Generated At</span>
        </div>
        <span className="text-[10px] font-bold">{timestamp || "Calculating..."}</span>
      </div>

      <div className="space-y-4">
        <section className="space-y-2">
          <h4 className="text-[10px] font-black uppercase tracking-widest text-primary">Factual Analysis</h4>
          <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/5 space-y-3">
            <ReportItem label="Total Hardware RAM" value={metrics?.ram ? `${metrics.ram} GB (Approx)` : "Unavailable"} />
            <ReportItem label="Storage Quota" value={metrics?.storage !== null ? `${metrics.storage}% Used` : "Unavailable"} />
            <ReportItem label="Power Resource" value={metrics?.battery !== null ? `${metrics.battery}%` : "Unavailable"} />
            <ReportItem label="Network Latency" value={networkStats ? `${networkStats.ping} ms` : "Pending Test"} />
          </div>
        </section>

        <section className="space-y-2">
          <h4 className="text-[10px] font-black uppercase tracking-widest text-primary">System Integrity</h4>
          <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/5 space-y-3">
             <div className="flex items-start gap-3">
                <CheckCircle2 className="h-4 w-4 text-green-500 shrink-0" />
                <p className="text-[11px] font-medium leading-relaxed">No simulated or "fake" data detected in this report. All values are derived from standard ECMA/Browser hardware interfaces.</p>
             </div>
          </div>
        </section>

        <button 
          onClick={() => window.print()}
          className="w-full h-12 rounded-2xl bg-primary text-primary-foreground font-black uppercase tracking-widest text-xs flex items-center justify-center gap-2 shadow-lg hover:opacity-90 transition-all"
        >
          <Download className="h-4 w-4" /> Print PDF Report
        </button>
      </div>
    </div>
  );
}

function ReportItem({ label, value }: { label: string, value: string }) {
  return (
    <div className="flex justify-between items-center border-b border-white/5 pb-2 last:border-0 last:pb-0">
      <span className="text-[9px] font-black uppercase opacity-40">{label}</span>
      <span className="text-[10px] font-bold">{value}</span>
    </div>
  )
}
