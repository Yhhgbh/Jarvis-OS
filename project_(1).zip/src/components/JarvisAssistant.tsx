
"use client"

import * as React from "react"
import { X, Loader2, BrainCircuit, ShieldAlert, Wifi, Zap, Smartphone, Mic, Volume2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { analyzeAndDiagnoseDeviceHealth, type AnalyzeAndDiagnoseDeviceHealthOutput } from "@/ai/flows/analyze-and-diagnose-device-health"
import { ScrollArea } from "@/components/ui/scroll-area"
import { cn } from "@/lib/utils"

interface JarvisAssistantProps {
  metrics: { ram: number | null; storage: number | null; battery: number | null };
  networkStats: { ping: number; downlink: number } | null;
  language: string;
}

export function JarvisAssistant({ metrics, networkStats, language }: JarvisAssistantProps) {
  const [isOpen, setIsOpen] = React.useState(false);
  const [diagnosis, setDiagnosis] = React.useState<AnalyzeAndDiagnoseDeviceHealthOutput | null>(null);
  const [isLoading, setIsLoading] = React.useState(false);
  const [isOffline, setIsOffline] = React.useState(false);

  React.useEffect(() => {
    setIsOffline(!navigator.onLine);
    const update = () => setIsOffline(!navigator.onLine);
    window.addEventListener('online', update);
    window.addEventListener('offline', update);
    return () => {
      window.removeEventListener('online', update);
      window.removeEventListener('offline', update);
    };
  }, []);

  const getLocalDiagnosis = (type: string) => {
    const res = { status: "Verified Hardware", cause: "System within parameters", fix: "No immediate action" };
    if (type === 'battery' && typeof metrics.battery === 'number' && metrics.battery < 20) {
      res.status = "Battery Low";
      res.cause = `Charge is ${metrics.battery}%`;
      res.fix = "Plug in your charger";
    } else if (type === 'storage' && typeof metrics.storage === 'number' && metrics.storage > 90) {
      res.status = "Storage High";
      res.cause = `Capacity at ${metrics.storage}%`;
      res.fix = "Manual folder cleanup";
    } else if (type === 'network' && networkStats && typeof networkStats.ping === 'number' && networkStats.ping > 400) {
      res.status = "Network Lag";
      res.cause = "High signal latency";
      res.fix = "Switch to better coverage";
    }
    return { healthScore: 0, statusSummary: [], jarvisResponse: res } as AnalyzeAndDiagnoseDeviceHealthOutput;
  };

  const handleAsk = async (type: any) => {
    setIsLoading(true);
    try {
      if (isOffline) {
        setDiagnosis(getLocalDiagnosis(type));
      } else {
        const result = await analyzeAndDiagnoseDeviceHealth({
          ramUsagePercentage: 0,
          storageUsagePercentage: metrics.storage || 0,
          batteryPercentage: metrics.battery || 0,
          isCharging: false,
          latency: networkStats?.ping,
          downlink: networkStats?.downlink,
          language: language as any,
          queryType: type,
        });
        setDiagnosis(result);
      }
    } catch (e) {
      setDiagnosis(getLocalDiagnosis(type));
    } finally {
      setIsLoading(false);
    }
  };

  const queries = [
    { id: 'slow', label: 'Why is it slow?', icon: Smartphone },
    { id: 'battery', label: 'Battery drain?', icon: Zap },
    { id: 'storage', label: 'Storage full?', icon: ShieldAlert },
    { id: 'network', label: 'How is network?', icon: Wifi },
  ] as const;

  return (
    <>
      <div className="fixed bottom-6 right-6 z-[100]">
        <Button 
          onClick={() => setIsOpen(true)}
          className="h-14 w-14 rounded-3xl bg-black/90 backdrop-blur-xl border border-white/10 shadow-2xl hover:scale-105 transition-all flex flex-col items-center justify-center gap-1 group overflow-hidden"
        >
          <span className="text-xl">🤖</span>
          <span className="text-[7px] font-black uppercase text-primary">JARVIS</span>
        </Button>
      </div>

      {isOpen && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-background/90 backdrop-blur-md">
          <Card className="w-full max-w-sm h-[70vh] flex flex-col glass-card border-none overflow-hidden shadow-2xl">
            <div className="p-4 border-b border-white/5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-xl bg-primary/20 flex items-center justify-center text-primary font-black">JAR</div>
                <div>
                  <h3 className="text-[10px] font-black uppercase tracking-widest">JARVIS Assistant</h3>
                  <p className="text-[8px] font-black text-muted-foreground uppercase">{isOffline ? "Offline Mode" : "Online Mode"}</p>
                </div>
              </div>
              <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)} className="rounded-xl h-8 w-8">
                <X className="h-4 w-4" />
              </Button>
            </div>

            <ScrollArea className="flex-1 p-4">
              <div className="space-y-6">
                {!diagnosis && !isLoading ? (
                  <div className="grid grid-cols-1 gap-2">
                    {queries.map((q) => (
                      <Button 
                        key={q.id}
                        variant="outline" 
                        onClick={() => handleAsk(q.id)}
                        className="h-auto py-4 px-5 rounded-2xl flex items-center justify-between text-[10px] font-black uppercase tracking-widest border-white/5 bg-white/[0.02] hover:bg-primary/10 transition-all text-left"
                      >
                        <div className="flex items-center gap-3">
                          <q.icon className="h-4 w-4 text-primary" />
                          {q.label}
                        </div>
                      </Button>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-6">
                    {isLoading ? (
                      <div className="flex flex-col items-center py-20 gap-4">
                        <Loader2 className="h-10 w-10 text-primary animate-spin" />
                        <p className="text-[9px] font-black uppercase tracking-widest animate-pulse">Analyzing Metrics...</p>
                      </div>
                    ) : diagnosis && (
                      <div className="space-y-4">
                        <div className="grid gap-3">
                           <div className="p-4 rounded-2xl bg-primary/5 border border-primary/10">
                              <p className="text-[8px] font-black uppercase text-primary mb-1">Status</p>
                              <p className="text-sm font-black tracking-tight">{diagnosis.jarvisResponse.status}</p>
                           </div>
                           <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/5">
                              <p className="text-[8px] font-black uppercase text-muted-foreground mb-1">Reason</p>
                              <p className="text-[11px] font-bold leading-relaxed">{diagnosis.jarvisResponse.cause}</p>
                           </div>
                           <div className="p-4 rounded-2xl bg-green-500/5 border border-green-500/20">
                              <p className="text-[8px] font-black uppercase text-green-500 mb-1">Fix</p>
                              <p className="text-[11px] font-black uppercase tracking-tight">{diagnosis.jarvisResponse.fix}</p>
                           </div>
                        </div>
                        <Button 
                          variant="ghost" 
                          onClick={() => setDiagnosis(null)}
                          className="w-full text-[9px] font-black uppercase tracking-widest h-12 rounded-2xl border border-white/5"
                        >
                          Ask Again
                        </Button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </ScrollArea>
          </Card>
        </div>
      )}
    </>
  );
}
