
"use client"

import * as React from "react"
import { Cpu, HardDrive, ShieldCheck, Zap, AlertCircle, Sparkles } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { cn } from "@/lib/utils"

interface HealthDashboardProps {
  onMetricsUpdate: (metrics: { ram: number | null; storage: number | null; battery: number | null }) => void;
  status: string;
}

export function HealthDashboard({ onMetricsUpdate, status }: HealthDashboardProps) {
  const [ramTotal, setRamTotal] = React.useState<number | null>(null)
  const [storageUsage, setStorageUsage] = React.useState<number | null>(null)
  const [batteryLevel, setBatteryLevel] = React.useState<number | null>(null)

  React.useEffect(() => {
    const updateMetrics = async () => {
      // Real RAM estimate
      const memory = (navigator as any).deviceMemory || null;
      setRamTotal(memory);

      // Real Storage estimate
      let currentStorage: number | null = null;
      if (navigator.storage && navigator.storage.estimate) {
        const estimate = await navigator.storage.estimate();
        if (estimate.usage !== undefined && estimate.quota !== undefined) {
          currentStorage = Math.round((estimate.usage / estimate.quota) * 100);
          setStorageUsage(currentStorage);
        }
      }

      // Real Battery level
      let currentBattery: number | null = null;
      if ('getBattery' in navigator) {
        const battery: any = await (navigator as any).getBattery();
        currentBattery = Math.round(battery.level * 100);
        setBatteryLevel(currentBattery);
      }

      onMetricsUpdate({
        ram: memory,
        storage: currentStorage,
        battery: currentBattery,
      });
    };

    updateMetrics();
    const interval = setInterval(updateMetrics, 15000);
    return () => clearInterval(interval);
  }, [onMetricsUpdate]);

  const getStatusConfig = () => {
    switch(status) {
      case "Operational": return { label: "Operational", color: "text-green-500", icon: ShieldCheck };
      case "Warning": return { label: "Warning", color: "text-yellow-500", icon: AlertCircle };
      case "Critical": return { label: "Critical", color: "text-red-500", icon: Zap };
      default: return { label: "Checking...", color: "text-primary", icon: Sparkles };
    }
  };

  const config = getStatusConfig();

  return (
    <div className="space-y-4">
      <Card className="glass-card border-none overflow-hidden relative group">
        <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 rounded-full blur-3xl -mr-16 -mt-16" />
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-8">
            <div className="space-y-1">
              <p className="text-[10px] font-black text-muted-foreground uppercase tracking-[0.4em]">Real-Time Hardware Status</p>
              <div className="flex items-center gap-3">
                 <config.icon className={cn("h-6 w-6", config.color)} />
                 <h2 className={cn("text-3xl font-black tracking-tighter uppercase", config.color)}>{config.label}</h2>
              </div>
            </div>
            <div className="text-right">
              <span className="text-xl font-black uppercase tracking-widest opacity-40">System Scan</span>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-2">
            {[
              { label: "RAM", status: ramTotal ? "Active" : "Err" },
              { label: "Storage", status: storageUsage !== null ? `${storageUsage}%` : "Err" },
              { label: "Battery", status: batteryLevel !== null ? `${batteryLevel}%` : "Err" },
              { label: "Signal", status: "Linked" }
            ].map((item, i) => (
              <div key={i} className="flex flex-col items-center gap-2 p-3 rounded-2xl bg-white/[0.03] border border-white/5">
                <span className="text-[8px] font-black uppercase opacity-50">{item.label}</span>
                <span className="text-[10px] font-bold text-primary">{item.status}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 gap-3">
        <Card className="glass-card overflow-hidden border-none">
          <CardContent className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="p-1.5 rounded-lg bg-primary/10 text-primary">
                <Cpu className="h-4 w-4" />
              </div>
              <span className="text-xl font-black tracking-tighter">
                {ramTotal ? `${ramTotal}GB` : 'N/A'}
              </span>
            </div>
            <p className="text-[10px] font-black uppercase tracking-widest opacity-60">Physical memory</p>
          </CardContent>
        </Card>

        <Card className="glass-card overflow-hidden border-none">
          <CardContent className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="p-1.5 rounded-lg bg-accent/10 text-accent">
                <HardDrive className="h-4 w-4" />
              </div>
              <span className="text-xl font-black tracking-tighter">
                {storageUsage !== null ? `${storageUsage}%` : 'N/A'}
              </span>
            </div>
            <div className="space-y-1.5">
              <Progress value={storageUsage || 0} className="h-1" />
              <p className="text-[10px] font-black uppercase tracking-widest opacity-60">Used space</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
